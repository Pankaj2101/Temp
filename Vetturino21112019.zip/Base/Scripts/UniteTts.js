﻿// Idea borrowed from https://www.google.com/intl/en/chrome/demos/speech.html
// &             from https://codeburst.io/html5-speech-recognition-api-670846a50e92

function ClsUniteTts()
{
	var This = this;

	var SampleVoices =
		[
			{ lang: "en-US", name: "Microsoft David Desktop - English (United States)" },
			{ lang: "en-US", name: "Microsoft Zira Desktop - English (United States)" },
			{ lang: "de-DE", name: "Google Deutsch" },
			{ lang: "en-US", name: "Google US English" },
			{ lang: "en-GB", name: "Google UK English Female" },
			{ lang: "en-GB", name: "Google UK English Male" },
			{ lang: "es-ES", name: "Google español" },
			{ lang: "es-US", name: "Google español de Estados Unidos" },
			{ lang: "fr-FR", name: "Google français" },
			{ lang: "hi-IN", name: "Google हिन्दी" },
			{ lang: "id-ID", name: "Google Bahasa Indonesia" },
			{ lang: "it-IT", name: "Google italiano" },
			{ lang: "ja-JP", name: "Google 日本語" },
			{ lang: "ko-KR", name: "Google 한국의" },
			{ lang: "nl-NL", name: "Google Nederlands" },
			{ lang: "pl-PL", name: "Google polski" },
			{ lang: "pt-BR", name: "Google português do Brasil" },
			{ lang: "ru-RU", name: "Google русский" },
			{ lang: "zh-CN", name: "Google&nbsp;普通话（中国大陆）" },
			{ lang: "zh-HK", name: "Google&nbsp;粤語（香港）" },
			{ lang: "zh-TW", name: "Google 國語（臺灣）" }
		];
	this.Speech;
	this.SpeechVoicesAvailable;
	this.SpeechUtterance;

	this.Init = function ()
	{
		if (!("speechSynthesis" in window))
		{
			console.log("Error", "Fatal Error! Browser does not support Speech!");
			return;
		}

		//Initialize Speech capabilities
		This.Speech = window.speechSynthesis;
		setTimeout(function ()
		{
			This.SpeechVoicesAvailable = This.Speech.getVoices();
			This.SpeechVoicesAvailable = This.Speech.getVoices();
			This.SpeechVoicesAvailable.forEach(function (NextVoice, Index)
			{
				console.log(Index + ': ' + NextVoice.name + ', ' + (NextVoice.default ? ' (default)' : ''));
			});
		}, 100);
		console.log("Info", "Speech Speech Capability Initialized");
		This.Speech.onvoiceschanged = function () { };
	};

	this.Speak = function (Text, CallBack)
	{
		if (This.Speech.speaking)
		{
			console.error('speechSynthesis.speaking');
			return;
		}
		if (Text !== '')
		{
			This.SpeechUtterance = new SpeechSynthesisUtterance(Text);
			This.SpeechUtterance.onend = function (event)
			{
				console.log('SpeechSynthesisUtterance.onend');
				if (CallBack)
				{
					CallBack();
				}
			};

			This.SpeechUtterance.onerror = function (event)
			{
				console.log('SpeechSynthesisUtterance.onerror');
			};

			This.SpeechUtterance.pitch = 1.5;  // 0 to 2
			This.SpeechUtterance.rate = 1.2;  // 0.5 to 2
			This.SpeechUtterance.voice = This.SpeechVoicesAvailable[1];
			//This.SpeechUtterance.voice = This.SpeechVoicesAvailable.filter(function (voice) { return voice.name == "Google 日本語"; })[0];
			This.Speech.speak(This.SpeechUtterance);

		}
	};

	This.Init();
};

var UniteTts = new ClsUniteTts();
