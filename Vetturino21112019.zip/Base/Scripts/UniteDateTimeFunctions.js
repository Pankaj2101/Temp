//Common Date/Time Extensions
Date.prototype.IsValid = function ()
{
	// An invalid date object returns NaN for getTime() and NaN is the only
	// object not strictly equal to itself.
	return this.getTime() === this.getTime();
};

Date.prototype.DaysInMonth = function ()
{
	return new Date(this.getFullYear(), this.getMonth() + 1, 0).getDate();
};

Date.prototype.ToString = function (Format)
{
	var MonthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
	var DayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
	var RetVal = Format;
	var strFullYear = this.getFullYear().toString();
	var strYear = strFullYear.substr(2, 2);
	var strMonth = ((this.getMonth() + 1) < 10 ? "0" : "") + (this.getMonth() + 1);
	var strDate = (this.getDate() < 10 ? "0" : "") + this.getDate();
	var strMonthName = MonthNames[this.getMonth()];
	var strDayName = DayNames[this.getDay()];
	var strHours = (this.getHours() < 10 ? "0" : "") + this.getHours();
	var strMinutes = (this.getMinutes() < 10 ? "0" : "") + this.getMinutes();
	var strSeconds = (this.getSeconds() < 10 ? "0" : "") + this.getSeconds();

	RetVal = RetVal.replace(/yyyy/g, strFullYear);
	RetVal = RetVal.replace(/yy/g, strYear);
	RetVal = RetVal.replace(/mmm/g, strMonthName);
	RetVal = RetVal.replace(/mm/g, strMonth);
	RetVal = RetVal.replace(/ddd/g, strDayName);
	RetVal = RetVal.replace(/dd/g, strDate);
	RetVal = RetVal.replace(/hh/g, strHours);
	RetVal = RetVal.replace(/nn/g, strMinutes);
	RetVal = RetVal.replace(/ss/g, strSeconds);
	return RetVal;
};

Date.prototype.AddDays = function(Days)
{
	return new Date(this.setDate(this.getDate() + Days));
}

Date.prototype.AddMonths = function(Months)
{
	return new Date(this.setMonth(this.getMonth() + Months));
};

Date.prototype.AddYears = function(Years)
{
	return new Date(this.setYear(this.getFullYear() + Years));
}

Date.prototype.SecondsElapsed = function ()
{
	return this.getMinutes() * 60 + this.getSeconds() + this.getMilliseconds() / 1000;
};

Date.prototype.GetNetMills = function ()
{
	return this.getTime();
}

Date.prototype.GetLastMonday = function()
{
	var Monday = new Date(this.getTime());
  	Monday.setDate(Monday.getDate() + 1 - Monday.getDay() );
  	if(Monday.getDate() > this.getDate())
  	{
 		Monday.setDate(Monday.getDate() - 7);
 	}
	return Monday;
}


//Common other Date/Time Functions
function GetRandomDate(DtFrom, DtTo)
{
	var RandDtDiff = Math.ceil(Math.abs(DtFrom.getTime() - DtTo.getTime()) * Math.random() / (1000 * 3600 * 24));
	var DtNew = DtFrom;

	DtNew.setDate(DtNew.getDate() + RandDtDiff);
	return DtNew;
}

function TimeStamp(DateString)
{
	return new Date(DateString).getTime();
}

function IsValidDate(GivenValue)
{
	if (Object.prototype.toString.call(GivenValue) === "[object Date]")
	{
		return (GivenValue.getTime() === GivenValue.getTime());
	}
	return false;
}

function Tm_HHMM2Date(GivenTimeString, Seperator)
{
    var SplitString;
    try
    {
        var RetVal = new Date();
        if (Seperator)
        {
            SplitString = GivenDateString.split(Seperator);
        }
        else
        {
            SplitString[0] = GivenDateString.substr(0, 2);
            SplitString[1] = GivenDateString.substr(2, 2);
        }
        return (new Date(RetVal.getFullYear(), RetVal.getMonth(), RetVal.getDate(), SplitString[0], SplitString[1]));
    }
    catch (ex)
    {
        return (new Date());
    }
}

function Tm_Date2HHMM(GivenDate, Seperator)
{
    var RetVal = "";
    RetVal += (GivenDate.getHours() < 10 ? "0" : "") + GivenDate.getHours();
    RetVal += (Seperator ? Seperator : "");
    RetVal += ((GivenDate.getMinutes() + 1) < 10 ? "0" : "") + GivenDate.getMinutes();
    return RetVal;
}

String.prototype.ToDate = function(Seperator, Format)
{
	var MonthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
	var SplitString = [];
	var intFullYear;
	var intMonth;
	var intDate;
	var intHour = 0;
	var intMinute = 0;
	var RetDate;

	try
	{
		if (Seperator)
		{
			SplitString = this.split(Seperator);
		}
		else
		{
			SplitString[0] = this.substr(0, 2);
			SplitString[1] = this.substr(3, 2);
			SplitString[2] = this.substr(6, 4);
			if(this.length > 10)
			{
				SplitString[3] = this.substr(11, 2);
				SplitString[4] = this.substr(14, 2);
			}
		}

		if (Format == "DMY")
		{
			intFullYear = parseInt(SplitString[2], 10);
			intMonth = parseInt(SplitString[1], 10);
			intDate = parseInt(SplitString[0], 10);
		}
		else if (Format == "DYM")
		{
			intFullYear = parseInt(SplitString[1], 10);
			intMonth = parseInt(SplitString[2], 10);
			intDate = parseInt(SplitString[0], 10);
		}
		else if (Format == "MDY")
		{
			intFullYear = parseInt(SplitString[2], 10);
			intMonth = parseInt(SplitString[0], 10);
			intDate = parseInt(SplitString[1], 10);
		}
		else if (Format == "MYD")
		{
			intFullYear = parseInt(SplitString[1], 10);
			intMonth = parseInt(SplitString[0], 10);
			intDate = parseInt(SplitString[2], 10);
		}
		else if (Format == "YDM")
		{
			intFullYear = parseInt(SplitString[0], 10);
			intMonth = parseInt(SplitString[2], 10);
			intDate = parseInt(SplitString[1], 10);
		}
		else if (Format == "MMMY")
		{
			intFullYear = parseInt(SplitString[1], 10);
			intMonth = MonthNames.indexOf(SplitString[0]) + 1;
			intDate = 1;
		}
		else if (Format = "DMY HM")
		{
			intFullYear = parseInt(SplitString[2], 10);
			intMonth = parseInt(SplitString[1], 10);
			intDate = parseInt(SplitString[0], 10);
			intHour = parseInt(SplitString[3], 10);
			intMinute = parseInt(SplitString[4], 10);
		}
		else
		{
			intFullYear = parseInt(SplitString[0], 10);
			intMonth = parseInt(SplitString[1], 10);
			intDate = parseInt(SplitString[2], 10);
		}
		RetDate = new Date(intFullYear, (intMonth - 1), intDate, intHour, intMinute);
		if (!RetDate.IsValid())
		{
			RetDate = new Date();
		}
		return RetDate;
	}
	catch (ex)
	{
		return (new Date());
	}
}
