﻿/*
	Copyright (c) 2019 Parth Sharma

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the "Software"), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in all
	copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
	SOFTWARE.
*/

var View = [];
var UI =
{
	ViewsToLoad:
		[
			"PopupConfirm",
			"PopupCalendar",
			"PopupCombo"
		],

	UpdateMenu: function ()
	{
		//ToDo: Develop Menu to come from DB
		var Menu = //Eventually this needs to come from DB
		{
			Menus:
				[
					{
						IconClass: "icon-home",
						Title: "Dashboard",
						Link: "ViewDashboard.php",
						IsOpen: true,
						HasSubMenu: false,
						SubMenu: []
					},
					{
						IconClass: "fa fa-flash",
						Title: "Live View",
						Link: "javascript:;",
						IsOpen: false,
						HasSubMenu: true,
						SubMenu:
							[
								{
									IconClass: "fa fa-location-arrow",
									Title: "Location Tracking",
									Link: "ViewVehicles.php"
								},
								{
									IconClass: "icon-graph",
									Title: "Graphical Analysis",
									Link: "ViewGraphicalData.php"
								},
								{
									IconClass: "icon-list",
									Title: "Data Analysis",
									Link: "ViewDataList.php"
								}
							]
					},
					{
						IconClass: "fa fa-table",
						Title: "Reports",
						Link: "javascript:;",
						IsOpen: false,
						HasSubMenu: true,
						SubMenu:
							[
								{
									IconClass: "icon-users",
									Title: "View Alerts",
									Link: "ViewMasterAccounts.php"
								},
								{
									IconClass: "icon-users",
									Title: "View Log",
									Link: "ViewMasterAccounts.php"
								}
							]
					},
					{
						IconClass: "fa fa-bullhorn",
						Title: "Broadcast",
						Link: "javascript:;",
						IsOpen: false,
						HasSubMenu: true,
						SubMenu:
							[
								{
									IconClass: "icon-users",
									Title: "Message",
									Link: "ViewBroadcastMessage.php"
								}
							]
					},
					{
						IconClass: "icon-note",
						Title: "Masters",
						Link: "javascript:;",
						IsOpen: false,
						HasSubMenu: true,
						SubMenu:
							[
								{
									IconClass: "icon-layers",
									Title: "Manage Users",
									Link: "ViewMasterUsers.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Drivers",
									Link: "ViewMasterDrivers.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Vehicles",
									Link: "ViewMasterVehicles.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Devices",
									Link: "ViewMasterDevices.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Device Parameters",
									Link: "ViewMasterDeviceTag.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Configuration",
									Link: "ViewMasterConfig.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Companies",
									Link: "ViewMasterCompanies.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Units",
									Link: "ViewMasterUnits.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Unit Rights",
									Link: "ViewMasterUnitRights.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Menus",
									Link: "ViewMasterMenus.php"
								},
								{
									IconClass: "icon-layers",
									Title: "Manage Menu Rights",
									Link: "ViewMasterMenuRights.php"
								}
							]
					},
					{
						IconClass: "fa fa-info-circle",
						Title: "About",
						Link: "ViewAbout.php",
						IsOpen: false,
						HasSubMenu: false,
						SubMenu: []
					}
				]
		};
		$(".page-sidebar-menu").html(TmplMenuList(Menu));

		$(".nav-item").click(function ()
		{
			var ButtonClicked = $(this);

			if (!ButtonClicked.hasClass("parent-menu"))
			{
				$(".nav-item").removeClass("active");
				ButtonClicked.addClass("active");
				ButtonClicked.parent().parent().addClass("active");
			}
			else if (!ButtonClicked.hasClass("HasSubMenu"))
			{
				$(".nav-item").removeClass("active");
				ButtonClicked.addClass("active");
			}

		});
	},

	ShowCallout: function (Top, Left, Height = 180, Width = 400, Content, CallBack)
	{
		//debugger;
		$(".CalloutBody").css("top", Top).css("left", Left);
		$(".CalloutBody").css("height", Height).css("width", Width);
		$(".CalloutBody .content p").html(Content);
		$(".CalloutBody").show();
		UniteTts.Speak(Content, function ()
		{
			if (CallBack)
			{
				CallBack();
			}
		});
	},

	HideCallout: function ()
	{
		$(".CalloutBody").hide();
	},

	SetPageTitle: function (GivenTitle, GivenSubTitle)
	{
		$(".Title").html(GivenTitle + "&nbsp;<small>" + GivenSubTitle + "</small>");
	},

	ShowPageTitleBar: function (Show)
	{
		//if (Show)
		//{
		//	$(".topcoat-navigation-bar").show();
		//}
		//else
		//{
		//	$(".topcoat-navigation-bar").hide();
		//}
	},

	MenuHide: function ()
	{
		//$(".side-nav").slideUp(200);
	},

	MenuToggle: function ()
	{
		//if ($(".side-nav").is(":visible"))
		//{
		//	$(".side-nav").slideUp(200);
		//}
		//else
		//{
		//	$(".side-nav").slideDown(200);
		//}
	},

	BindDefaultButton: function ()
	{
		$("body").bind("keydown", function (event)
		{
			if ((event.keyCode ? event.keyCode : (event.which ? event.which : event.charCode)) == 13)
			{
				$(".DefaultButton").click();
				return false;
			}
			return true;
		});
	},

	BindScreenResize: function ()
	{
		//$(window).resize(function ()
		//{
		//	console.log($(".ViewContainer").height() + ", " + $("body").height() + ", " + ($("body").height() - 160));
		//	$(".ViewContainer").height(($("body").height() - 160));
		//	console.log($(".ViewContainer").height() + ", " + $("body").height());
		//});
	},

	BindHashChange: function (CallBackFunction)
	{
		$(window).on("hashchange", CallBackFunction);
	},

	BindMenuButton: function ()
	{
		//$(".ButtonMenu").click(function ()
		//{
		//	UI.MenuToggle();
		//});
	},

	BindDatePickerControls: function ()
	{
		/*$('body').on('click', '.PopupDatePicker', function ()
	    {
	        ClsDatePicker(this);
		});*/
		//debugger;
		//$(document).on('click', '.date-picker', function ()
		//{
		//	debugger;
		//	$(this).datepicker({
		//		orientation: "left",
		//		autoclose: true
		//	});
		//});
	},

	BindCombos: function (GivenCombos, ComboArray, PromptOption)
	{
		$(GivenCombos).each(function ()
		{
			var $NextSelect = $(this);
			var LastSelectedValue = $NextSelect.val();

			$NextSelect.empty();
			$NextSelect.append("<option disabled selected value>" + PromptOption + "</option>");
			$.each(ComboArray, function (index, value)
			{
				$NextSelect.append("<option value='" + value.Id + "'" + (value.Id == LastSelectedValue ? " selected " : "") + " >" + value.Name + "</option>");
			});
		});
	},

	Alert: function (Type, Text, TimeOut)
	{
		toastr.options =
			{
				"closeButton": true,
				"timeOut": (Type.toLowerCase() == "error" ? 0 : (TimeOut ? TimeOut : 5000))
			};
		toastr[Type.toLowerCase()](Text, Type);
	},

	Confirm: function (GivenText, CallBack)
	{
		if (CallBack)
		{
			bootbox.dialog({
				message: GivenText,
				onEscape: function () { CallBack("Close"); },
				backdrop: true,
				buttons:
				{
					Yes:
					{
						label: 'Yes',
						className: 'btn-primary',
						callback: function () { CallBack("Yes"); }
					},
					No:
					{
						label: 'No',
						callback: function () { CallBack("No"); }
					}
				}
			});
		}
		else
		{
			bootbox.dialog({
				message: GivenText,
				onEscape: true,
				backdrop: true,
				buttons:
				{
					Yes:
					{
						label: 'Yes',
						className: 'btn-primary'
					},
					No:
					{
						label: 'No'
					}
				}
			});
		}
	},

	WaitShow: function (GivenMessage, OnComplete)
	{
		$(".PopupWaitText").html(GivenMessage);
		$("#PopupWait").show(10, function ()
		{
			$("#PopupWait  .UnitePopup").Center();
			if (OnComplete)
			{
				setTimeout(
					OnComplete,
					1000);
			}
		});
	},

	WaitHide: function ()
	{
		$("#PopupWait").hide();
	},

	// Handles counterup plugin wrapper
    HandleCounterup: function() {
        if (!$().counterUp) {
            return;
        }

        $("[data-counter='counterup']").counterUp({
            delay: 10,
            time: 1000
        });
    }
};

function ClsCheckListPicker()
{
	var This = this;

	this.ButtonToBind;;
	this.Mode;
	this.Title;
	this.Data;
	this.CallBack;
	this.SelectedItemIds;
	this.SelectedItemNames;
	this.TmplPopupMain = {};

	//.Init(".ButtonTagType", "SingleSelect", "Select Device Type", GlbTableTagType, "SelectedTagTypeId", "SelectedTagTypeName", FromDateChanged)
	this.Init = function (ButtonToBind, Mode, Title, Data, SelectedItemIds, CallBack)
	{
		This.ButtonToBind = ButtonToBind;
		This.Mode = Mode;
		This.Title = Title;
		This.Data = Data;
		This.SelectedItemIds = SelectedItemIds;
		This.CallBack = CallBack;

		$(ButtonToBind).click(function ()
		{
			var PopupId = Common.GetNewPopupId();

			$("body").append("<div id='" + PopupId + "' style='display: block'>" + View["PopupCombo"] + "</div>");
			PopupId = "#" + PopupId;
			GlbPopupIndex++;

			This.TmplPopupMain = Handlebars.compile($("#TmplPopupMain").html());
			$(PopupId + " .Title").html(This.Title);
			$(PopupId + " .UtListContainer table").html(This.TmplPopupMain(This.Data));
			$(PopupId + " .UniteMask").css("z-index", GlbPopupIndex * 2 + 100)
			$(PopupId + " .UnitePopup").css("z-index", GlbPopupIndex * 2 + 101)
			$(PopupId + " .UtListContainer").css({ "max-height": $(window).height() - 180 });			//Set List Height

			if (This.Mode == "SingleSelect") //Check Uncheck the items that have already been selected
			{
				$(PopupId + " input[data-id='" + This.SelectedItemIds + "']").prop('checked', true);
			}
			else
			{
				$.each(This.SelectedItemIds, function (index, value)
				{
					$(PopupId + " input[data-id='" + value + "']").prop('checked', true);
				})
			}

			$(PopupId + " .UnitePopup").Center(); //Center and show the list

			// Attach & handle events.
			$(PopupId + " .ButtonClose, " + PopupId + " .ButtonOk").on("click", function ()
			{
				var ButtonClicked = "";

				if (this.className.includes("ButtonClose"))
				{
					ButtonClicked = "Close";
				}
				else if (this.className.includes("ButtonOk"))
				{
					ButtonClicked = "Ok";
				}

				GlbPopupIndex--;
				$(PopupId).remove();
				if (This.CallBack)
				{
					This.CallBack(ButtonClicked, This.SelectedItemIds, This.SelectedItemNames);
				}
				return Common.PrvntEvtPropg();
			});

			$(PopupId + " .ClickToSelect").change(function ()
			{
				if (This.Mode == "SingleSelect")
				{
					$(PopupId + " input:checkbox").prop('checked', false);
					$(this).prop('checked', true);
					This.SelectedItemIds = $(this).attr("data-id");
					This.SelectedItemNames = $(this).attr("data-name");
					return Common.PrvntEvtPropg();
				}
				else
				{
					This.SelectedItemIds = [];
					This.SelectedItemNames = [];
					$(PopupId + " input:checked").each(function ()
					{
						This.SelectedItemIds.push($(this).attr("data-id"));
						This.SelectedItemNames.push($(this).attr("data-name"));
					});
					return Common.PrvntEvtPropg();
				}
			});
		});
	};

	this.Show = function (Title, Data, SelectedItemIds, SelectedItemNames, CallBack)
	{
		var PopupId = Common.GetNewPopupId();

		This.Mode = "SingleSelect";
		This.ButtonToBind = "";
		This.Title = Title;
		This.Data = Data;
		This.SelectedItemIds = SelectedItemIds;
		This.SelectedItemNames = SelectedItemNames;
		This.CallBack = CallBack;

		$("body").append("<div id='" + PopupId + "' style='display: block'>" + View["PopupCombo"] + "</div>");
		PopupId = "#" + PopupId;
		GlbPopupIndex++;

		This.TmplPopupMain = Handlebars.compile($("#TmplPopupMain").html());
		$(PopupId + " .Title").html(This.Title);
		$(PopupId + " .UtListContainer table").html(This.TmplPopupMain(This.Data));
		$(PopupId + " .UniteMask").css("z-index", GlbPopupIndex * 2 + 100)
		$(PopupId + " .UnitePopup").css("z-index", GlbPopupIndex * 2 + 101)
		$(PopupId + " .UtListContainer").css({ "max-height": $(window).height() - 180 });			//Set List Height
		$(PopupId + " input[data-id='" + This.SelectedItemIds + "']").prop('checked', true);
		$(PopupId + " .UnitePopup").Center(); //Center and show the list

		// Attach & handle events.
		$(PopupId + " .ButtonClose, " + PopupId + " .ButtonOk").on("click", function ()
		{
			var ButtonClicked = "";

			if (this.className.includes("ButtonClose"))
			{
				ButtonClicked = "Close";
			}
			else if (this.className.includes("ButtonOk"))
			{
				ButtonClicked = "Ok";
			}

			GlbPopupIndex--;
			$(PopupId).remove();
			if (This.CallBack)
			{
				This.CallBack(ButtonClicked, This.SelectedItemIds, This.SelectedItemNames);
			}
			return Common.PrvntEvtPropg();
		});

		$(PopupId + " .ClickToSelect").change(function ()
		{
			if (This.Mode == "SingleSelect")
			{
				$(PopupId + " input:checkbox").prop('checked', false);
				$(this).prop('checked', true);
				This.SelectedItemIds = $(this).attr("data-id");
				This.SelectedItemNames = $(this).attr("data-name");
				return Common.PrvntEvtPropg();
			}
			else
			{
				This.SelectedItemIds = [];
				This.SelectedItemNames = [];
				$(PopupId + " input:checked").each(function ()
				{
					This.SelectedItemIds.push($(this).attr("data-id"));
					This.SelectedItemNames.push($(this).attr("data-name"));
				});
				return Common.PrvntEvtPropg();
			}
		});
	};
}

function ClsLineChart()
{
	var This = this;
	var TheChart = null;

	var randomScalingFactor = function ()
	{
		return Math.round(Math.random() * 100);
		//return 0;
	};
	var randomColorFactor = function ()
	{
		return Math.round(Math.random() * 255);
	};
	var randomColor = function (opacity)
	{
		return 'rgba(' + randomColorFactor() + ',' + randomColorFactor() + ',' + randomColorFactor() + ',' + (opacity || '.3') + ')';
	};

	var SeriesColorSolid = ["rgba(255, 117, 117, 1)", "rgba(213, 104, 253, 1)", "rgba(255, 219, 88, 1)", "rgba(135, 175, 199, 1)", "rgba(75, 254, 120, 1)", "rgba(255, 255, 132, 1)", "rgba(150, 105, 254, 1)", "rgba(249, 167, 176, 1)", "rgba(255, 180, 40, 1)", "rgba(36, 224, 251, 1)"];
	var SeriesColorTrans = ["rgba(255, 117, 117, 0.1)", "rgba(213, 104, 253, 0.1)", "rgba(255, 219, 88, 0.1)", "rgba(135, 175, 199, 0.1)", "rgba(75, 254, 120, 0.1)", "rgba(255, 255, 132, 0.1)", "rgba(150, 105, 254, 0.1)", "rgba(249, 167, 176, 0.1)", "rgba(255, 180, 40, 0.1)", "rgba(36, 224, 251, 0.1)"];

	var ChartConfig =
	{
		type: "line",
		data:
		{
			labels: [],
			datasets: []
		},
		options:
		{
			responsive: true,
			maintainAspectRatio: false,
			tooltips: { mode: "label" },
			hover: { mode: "dataset" },
			legend: { labels: { boxWidth: 18, fontColor: "lightgray", fontSize: 14 } },
			scales:
			{
				display: true,
				xAxes:
					[{
						display: true,
						ticks: { fontColor: "#ddd" },
						scaleLabel:
						{
							display: true,
							labelString: "X-Axis",
							fontColor: "#ddd",
							fontSize: 18
						}
					}],
				yAxes:
					[{
						display: true,
						ticks: { fontColor: "#ddd" },
						scaleLabel:
						{
							display: true,
							labelString: "Y-Axis",
							fontColor: "#ddd",
							fontSize: 18
						}
					}]
			}
		}
	};

	this.Render = function (ChartType, ChartCanvas, DataLabels, DataSeries, TagNames, XTitle, YTitle)
	{
		ChartConfig.data.labels = DataLabels;
		ChartConfig.options.scales.xAxes[0].scaleLabel.labelString = XTitle;
		ChartConfig.options.scales.yAxes[0].scaleLabel.labelString = YTitle;
		ChartConfig.data.datasets = [];

		for (var Count = 0; Count < DataSeries.length; Count++)
		{
			ChartConfig.data.datasets.push
				({
					fontColor: '#ffffff',
					label: TagNames[Count],
					pointBorderColor: 'white',
					borderColor: SeriesColorSolid[Count],
					backgroundColor: SeriesColorTrans[Count],
					data: DataSeries[Count]
				});

		}
		if (TheChart)
		{
			TheChart.destroy();
		}
		TheChart = new Chart($(ChartCanvas).get(0).getContext("2d"), ChartConfig);
	};
};

var ClsDatePicker = function (Control, CallBackFunction)
{
	var This = this;

	this.Control = $(Control);
	this.CallBackFunction = CallBackFunction;
	this.ControlDate = This.Control.val().ToDate("/", "DMY");
	this.TempDate = new Date();
	this.PopupId = "";
	this.MonthName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

	this.RenderDate = function (ChangedDate)
	{
		This.TempDate = ChangedDate;
		$(This.PopupId + " .DateDay").html(This.TempDate.getDate());
		$(This.PopupId + " .DateMonth").html(This.MonthName[This.TempDate.getMonth()]);
		$(This.PopupId + " .DateYear").html(This.TempDate.getFullYear());
		return Common.PrvntEvtPropg();
	};

	if (!This.ControlDate)
	{
		This.ControlDate = new Date();
	}

	GlbPopupIndex++;
	This.PopupId = Common.GetNewPopupId();
	$("body").append("<div id='" + This.PopupId + "' style='display: block'>" + View["PopupCalendar"] + "</div>");
	This.PopupId = "#" + This.PopupId;
	$(This.PopupId + " .UnitePopup").Center();
	$(This.PopupId + " .Title").html(This.Title);
	$(This.PopupId + " .UniteMask").css("z-index", GlbPopupIndex * 2 + 100)
	$(This.PopupId + " .UnitePopup").css("z-index", GlbPopupIndex * 2 + 101)
	$(This.PopupId + " .UnitePopup").css("z-index", GlbPopupIndex * 2 + 101)
	This.TempDate = This.ControlDate;
	This.RenderDate(This.TempDate);

	// Attach & handle events.
	$(This.PopupId + " .ButtonClose, " + This.PopupId + " .ButtonOk").click(function ()
	{
		var ButtonClicked = (this.className.includes("ButtonClose") ? "Close" : "Ok");

		$(This.PopupId).remove();
		GlbPopupIndex--;
		if (ButtonClicked == "Ok")
		{
			This.ControlDate = This.TempDate;
			$(This.Control).val(This.ControlDate.ToString("dd/mm/yyyy"))
		}
		if (This.CallBackFunction)
		{
			This.CallBackFunction(ButtonClicked, This.ControlDate, This.ControlDate.ToString("yyyy-mm-dd"));
		}
		return Common.PrvntEvtPropg();
	});

	$(This.PopupId + " .ButtonToday").click(function ()
	{
		This.RenderDate(new Date());
	});

	$(This.PopupId + " .ClickDecDay").click(function ()
	{
		This.RenderDate(This.TempDate.AddDays(-1));
	});

	$(This.PopupId + " .ClickDecMonth").click(function ()
	{
		This.RenderDate(This.TempDate.AddMonths(-1));
	});

	$(This.PopupId + " .ClickDecYear").click(function ()
	{
		This.RenderDate(This.TempDate.AddYears(-1));
	});

	$(This.PopupId + " .ClickIncDay").click(function ()
	{
		This.RenderDate(This.TempDate.AddDays(1));
	});

	$(This.PopupId + " .ClickIncMonth").click(function ()
	{
		This.RenderDate(This.TempDate.AddMonths(1));
	});

	$(This.PopupId + " .ClickIncYear").click(function ()
	{
		This.RenderDate(This.TempDate.AddYears(1));
	});
}

function ClsDateNavigator()
{
	var This = this;

	this.ButtonDate;
	this.Title;
	this.Date = new Date();
	this.TempDate = new Date();
	this.PopupId = "";
	this.CallBackFunction;
	this.MonthName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	this.DialogView = "PopupCalendar";
	this.ActiveTimer;

	// Common Methods 
	this.Init = function (ButtonDate, Title, StartDate, CallBackFunction)
	{
		This.ButtonDate = ButtonDate;
		This.Title = Title;
		This.CallBackFunction = CallBackFunction;
		This.Date = StartDate;
		if (!This.Date)
		{
			This.Date = new Date();
		}
		else if (typeof This.Date == "string")
		{
			This.Date = This.Date.ToDate("-", "YMD");
		}

		$(This.ButtonDate + " .ButtonPrevMonth").show();
		$(This.ButtonDate + " .ButtonPrev").show();
		$(This.ButtonDate + " .ButtonNext").show();
		$(This.ButtonDate + " .ButtonNextMonth").show();
		$(This.ButtonDate + " .DateTextHolder").html(This.Date.ToString("dd-mm-yyyy"))

		$(This.ButtonDate).click(function ()
		{
			GlbPopupIndex++;
			This.PopupId = Common.GetNewPopupId();
			$("body").append("<div id='" + This.PopupId + "' style='display: block'>" + View["PopupCalendar.html"] + "</div>");
			This.PopupId = "#" + This.PopupId;
			$(This.PopupId + " .UnitePopup").Center();
			$(This.PopupId + " .Title").html(This.Title);
			$(This.PopupId + " .UniteMask").css("z-index", GlbPopupIndex * 2 + 100)
			$(This.PopupId + " .UnitePopup").css("z-index", GlbPopupIndex * 2 + 101)
			$(This.PopupId + " .UnitePopup").css("z-index", GlbPopupIndex * 2 + 101)
			This.TempDate = This.Date;
			This.RenderDate();

			// Attach & handle events.
			$(This.PopupId + " .ButtonClose").click(function ()
			{
				This.Hide("Close");
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ButtonOk").click(function ()
			{
				This.Hide("Ok");
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ButtonToday").click(function ()
			{
				This.TempDate = new Date();
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ClickDecDay").click(function ()
			{
				This.TempDate = This.TempDate.AddDays(-1);
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ClickDecMonth").click(function ()
			{
				This.TempDate = This.TempDate.AddMonths(-1)
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ClickDecYear").click(function ()
			{
				This.TempDate = This.TempDate.AddYears(-1)
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ClickIncDay").click(function ()
			{
				This.TempDate = This.TempDate.AddDays(1)
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ClickIncMonth").click(function ()
			{
				This.TempDate = This.TempDate.AddMonths(1)
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});

			$(This.PopupId + " .ClickIncYear").click(function ()
			{
				This.TempDate = This.TempDate.AddYears(1)
				This.RenderDate();
				return Common.PrvntEvtPropg();
			});
		});

		$(This.ButtonDate + " .ButtonPrevMonth").click(function ()
		{
			This.Date.AddMonths(-1);
			This.Return("PrevMonth");
			return Common.PrvntEvtPropg();
		});

		$(This.ButtonDate + " .ButtonNextMonth").click(function ()
		{
			This.Date.AddMonths(1);
			This.Return("NextMonth");
			return Common.PrvntEvtPropg();
		});

		$(This.ButtonDate + " .ButtonPrev").click(function ()
		{
			This.Date.AddDays(-1);
			This.Return("Prev");
			return Common.PrvntEvtPropg();
		});

		$(This.ButtonDate + " .ButtonNext").click(function ()
		{
			This.Date.AddDays(1);
			This.Return("Next");
			return Common.PrvntEvtPropg();
		});
	};

	this.RenderDate = function ()
	{
		$(This.PopupId + " .DateDay").html(This.TempDate.getDate());
		$(This.PopupId + " .DateMonth").html(This.MonthName[This.TempDate.getMonth()]);
		$(This.PopupId + " .DateYear").html(This.TempDate.getFullYear());
	};

	this.Hide = function (ButtonClicked)
	{
		$(This.PopupId).remove();
		GlbPopupIndex--;
		if (ButtonClicked == "Ok")
		{
			This.Date = This.TempDate;
			This.Return(ButtonClicked);
		}
	};

	this.Return = function (ButtonClicked)
	{
		$(This.ButtonDate + " .DateTextHolder").html(This.Date.ToString("dd-mm-yyyy"))

		// in your click function, call clearTimeout
		window.clearTimeout(This.ActiveTimer);

		// then call setTimeout again to reset the timer
		This.ActiveTimer = window.setTimeout(function ()
		{
			if (This.CallBackFunction)
			{
				This.CallBackFunction(ButtonClicked, This.Date, This.Date.ToString("yyyy-mm-dd"));
			}
		}, 400);
	};

	this.SetDate = function (GivenDate)
	{
		This.Date = GivenDate;
		$(This.ButtonDate + " .DateTextHolder").html(This.Date.ToString("dd-mm-yyyy"))
		if (This.CallBackFunction)
		{
			This.CallBackFunction("Ok", This.Date, This.Date.ToString("yyyy-mm-dd"));
		}
	};

	this.GetDate = function ()
	{
		return This.Date;
	};
}

function ClsPaginator()
{
	var This = this;
	this.TotalRecords = 0;
	this.PageSize = 50;
	this.PageLast = 0;
	this.PageCurrent = 0;
	this.PageOffset = 0;
	this.ButtonPagination;
	this.TextBoxPage;
	this.CallBackFunction;
	this.ActiveTimer;

	//Paginator.Init(".ButtonPagination", ".PanelPagination", ".ButtonFirst", ".ButtonLast", ".ButtonPrev", ".ButtonNext")
	this.Init = function (ButtonPagination, PanelPagination, ButtonFirst, ButtonLast, ButtonPrev, ButtonNext, TextBoxPage, CallBackFunction)
	{
		This.ButtonPagination = ButtonPagination;
		This.TextBoxPage = TextBoxPage;
		This.CallBackFunction = CallBackFunction;

		//$(ButtonPagination).click(function ()
		//{
		//	var ButtonPagination = $(this);
		//	$(PanelPagination).css(
		//	{
		//		top: ButtonPagination.offset().top + ButtonPagination.outerHeight() + 10,
		//		left: ButtonPagination.offset().left + ButtonPagination.width() - 209
		//	})
		//	$(PanelPagination).toggle();
		//});

		$(ButtonFirst).click(function ()
		{
			if (This.PageCurrent != 1)
			{
				This.PageCurrent = 1;
				This.PageOffset = (This.PageCurrent - 1) * This.PageSize;
				$(This.TextBoxPage).html(This.PageCurrent);
				This.Hide();
			}
		});

		$(ButtonLast).click(function ()
		{
			if (This.PageCurrent != This.PageLast)
			{
				This.PageCurrent = This.PageLast;
				This.PageOffset = (This.PageCurrent - 1) * This.PageSize;
				$(This.TextBoxPage).html(This.PageCurrent);
				This.Hide();
			}
		});

		$(ButtonPrev).click(function ()
		{
			if (This.PageCurrent != 1)
			{
				This.PageCurrent--;
				This.PageOffset = (This.PageCurrent - 1) * This.PageSize;
				$(This.TextBoxPage).html(This.PageCurrent);
				This.Hide();
			}
		});

		$(ButtonNext).click(function ()
		{
			if (This.PageCurrent != This.PageLast)
			{
				This.PageCurrent++;
				This.PageOffset = (This.PageCurrent - 1) * This.PageSize;
				$(This.TextBoxPage).html(This.PageCurrent);
				This.Hide();
			}
		});
	};

	this.Hide = function (ButtonClicked)
	{
		// Rest the timer so that any previous click is not called back on
		window.clearTimeout(This.ActiveTimer);

		// Call Callback only  if timeout has elapsed
		This.ActiveTimer = window.setTimeout(function ()
		{
			if (This.CallBackFunction)
			{
				This.CallBackFunction(ButtonClicked);
			}
		}, 400);
	};

	this.SetTotalRecords = function (GivenValue)
	{
		This.TotalRecords = GivenValue;
		This.PageLast = Math.ceil(This.TotalRecords / This.PageSize);
		This.PageCurrent = 1;
		This.PageOffset = 0;
		$(This.TextBoxPage).html(This.PageCurrent);
	}

	this.SetPageSize = function (GivenValue)
	{
		This.PageSize = GivenValue;
		This.PageLast = Math.ceil(This.TotalRecords / This.PageSize);
		This.PageCurrent = 1;
		This.PageOffset = 0;
		$(This.TextBoxPage).html(This.PageCurrent);
	}
}



// Static Views
View.PopupCombo =
	`
		<div class="UniteMask"></div>
		<div class="UnitePopup" >
			<div class="topcoat-navigation-bar-popup">
				<div class="topcoat-navigation-bar__item left three-quarters">
					<h1 class="topcoat-navigation-bar__title Title">Select</h1>
				</div>
				<div class="topcoat-navigation-bar__item right quarter">
					<div class="topcoat-button--large Icomatic ButtonClose" style="vertical-align: middle; padding: 0 .563rem;">
						
					</div>
				</div>
			</div>
			<div class="UtListContainer" style="border: none; margin-bottom: 10px; text-align: center; overflow: auto; overflow-x: hidden">
				<table class="" cellpadding="0" cellspacing="0" style="width: 100%;">
				</table>
			</div>
			<div style="text-align: center">
				<div style="text-align: center">
					<button class="topcoat-button--large--cta ButtonOk DefaultButton">Ok</button>
				</div>
			</div>
		</div>

		<script id="TmplPopupMain" type="text/x-handlebars-template">
			{{#.}}
				<tr>
					<td style='width: 100%;text-align:left;'>
						<p>{{Name}}</p>
					</td>
					<td style='width:140px;text-align:left;'>
						<label class="topcoat-checkbox" style="display:block">
							<input type="checkbox" data-id="{{Id}}" data-name="{{Name}}" class="ClickToSelect">
							<div class="topcoat-checkbox__checkmark"></div>
						</label><br>
					</td>
				</tr>";
			{{/.}}
		</script>
	`;
View.PopupConfirm =
	`
		<div class="UniteMask"></div>
		<div class="UnitePopup" >
			<div class="topcoat-navigation-bar-popup">
				<div class="topcoat-navigation-bar__item left three-quarters">
					<h1 class="topcoat-navigation-bar__title Title Icomatic">Confirm!</h1>
				</div>
				<div class="topcoat-navigation-bar__item right quarter">
					<div class="topcoat-button--large Icomatic ButtonClose" style="vertical-align: middle; padding: 0 .563rem;">
						
					</div>
				</div>
			</div>
			<div class="UtListContainer" style="border: none; margin: 20px 5px 20px 5px; text-align: center;">
				Are you sure you want to delete?
			</div>
			<div style="text-align: center">
				<button class="topcoat-button--large--cta ButtonYes">Yes</button>
				<button class="topcoat-button--large--cta ButtonNo DefaultButton">No</button>
			</div>
		</div>
	`;
View.PopupCalendar =
	`
		<div class="UniteMask"></div>
		<div class="UnitePopup" style="width: 300px;">
			<div class="topcoat-navigation-bar-popup">
				<div class="topcoat-navigation-bar__item left three-quarters">
					<h1 class="topcoat-navigation-bar__title Title">Select</h1>
				</div>
				<div class="topcoat-navigation-bar__item right quarter">
					<div class="topcoat-button--large Icomatic ButtonClose" style="vertical-align: middle; padding: 0 .563rem;">
						
					</div>
				</div>
			</div>
			<div class="" style="border: none; margin-bottom: 20px; margin-top: 20px; text-align: center">
				<table class="" cellpadding="0" cellspacing="0" style="width: 240px; margin: 0 auto 0  auto;">
					<tr>
						<td class="ColumnDate" style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickIncDay" style="width: 65px;">+</button>
						</td>
						<td class="ColumnMonth" style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickIncMonth" style="width: 65px;">+</button>
						</td>
						<td class="ColumnYear" style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickIncYear" style="width: 65px;">+</button>
						</td>
					</tr>
					<tr>
						<td class="ColumnDate" style="text-align: center; padding-bottom: 2px;">
							<select class="SelectDateDay" style="width: 65px; height:30px"></select>
						</td>
						<td class="ColumnMonth" style="text-align: center; padding-bottom: 2px;">
							<select class="SelectDateMonth" style="width: 65px; height:30px"></select>
					   </td>
						<td style="text-align: center; padding-bottom: 2px;">
							<select class="SelectDateYear" style="width: 65px; height:30px"></select>
						</td>
					</tr>
					<tr>
						<td class="ColumnDate" style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickDecDay" style="width: 65px;">-</button>
						</td>
						<td class="ColumnMonth" style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickDecMonth" style="width: 65px;">-</button>
						</td>
						<td class="ColumnYear" style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickDecYear" style="width: 65px;">-</button>
						</td>
					</tr>
				</table>
			</div>
			<div style="text-align: center">
				<button class="topcoat-button--large--cta ButtonOk DefaultButton" style="margin-right: 5px; width: 67px;">Ok</button>
				<button class="topcoat-button--large--cta ButtonToday" style="margin-left: 5px;">Today</button>
			</div>
		</div>
	`;
View.PopupClock =
	`
		<div class="UniteMask"></div>
		<div class="UnitePopup" style="width: 300px">
			<div class="topcoat-navigation-bar-popup">
				<div class="topcoat-navigation-bar__ite left three-quarters">
					<h1 class="topcoat-navigation-bar__title Title">Select</h1>
				</div>
				<div class="topcoat-navigation-bar__item right quarter">
					<div class="topcoat-button--large Icomatic ButtonClose" style="vertical-align: middle; padding: 0 .563rem;">
						
					</div>
				</div>
			</div>
			<div class="" style="border: none; margin-bottom: 20px; margin-top: 20px; text-align: center">
				<table class="" cellpadding="0" cellspacing="0" style="width: 200px; margin: 0 auto 0  auto;">
					<tr>
						<td style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickIncHour" style="width: 50px;">+</button>
						</td>
						<td style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickIncMinute" style="width: 50px;">+</button>
						</td>
					</tr>
					<tr>
						<td style="text-align: center; padding-bottom: 2px;">
							<div class="topcoat-text-input--large TimeHour" style="width: 50px; vertical-align: baseline; display: inline-block;"></div>
						</td>
						<td style="text-align: center; padding-bottom: 2px;">
							<div class="topcoat-text-input--large TimeMinute" style="width: 50px; vertical-align: baseline; display: inline-block;"></div>
						</td>
					</tr>
					<tr>
						<td style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickDecHour" style="width: 50px;">-</button>
						</td>
						<td style="text-align: center; padding-bottom: 2px;">
							<button class="topcoat-button--large ClickDecMinute" style="width: 50px;">-</button>
						</td>
					</tr>
				</table>
			</div>
			<div style="text-align: center">
				<button class="topcoat-button--large--cta ButtonOk DefaultButton" style="margin-right: 5px; width: 67px;">Ok</button>
				<button class="topcoat-button--large--cta ButtonNow" style="margin-left: 5px;">Now</button>
			</div>
		</div>

		<script>
			var Popup =
			{
				Init: function (PopupId, Mode, Params, CallBackFunction)
				{
					var This = this;
					var CurrentHour = 10;
					var CurrentMinute = 0;

					$(PopupId + " .Title").html(Params.Title);
					$(This.PopupId + " .UnitePopup").Center();

					if (!Params.Time)
					{
						var CurrentDate = new Date();
						CurrentHour = CurrentDate.getHours();
						CurrentMinute = CurrentDate.getMinutes();
					}
					else if (typeof Params.Time == "string")
					{
						CurrentHour = parseInt(Params.Time.trim().substr(0, Params.Time.indexOf(":")), 10);
						CurrentMinute = parseInt(Params.Time.trim().substr(Params.Time.indexOf(":") + 1, 2), 10);
					}
					RenderTime();


					// Common Methods 
					function RenderTime()
					{
						$(PopupId + " .TimeHour").html((CurrentHour < 10 ? "0" : "") + CurrentHour);
						$(PopupId + " .TimeMinute").html((CurrentMinute < 10 ? "0" : "") + CurrentMinute);
					}

					this.Hide = function (ButtonClicked)
					{
						$(PopupId).remove();
						if (CallBackFunction)
						{
							CallBackFunction(ButtonClicked, (CurrentHour < 10 ? "0" : "") + CurrentHour + ":" + (CurrentMinute < 10 ? "0" : "") + CurrentMinute);
						}
					};

					// Attach & handle events.
					$(PopupId + " .ButtonClose").click(function ()
					{
						This.Hide("Close");
						return Common.PrvntEvtPropg();
					});

					$(PopupId + " .ButtonOk").click(function ()
					{
						This.Hide("Ok");
						return Common.PrvntEvtPropg();
					});

					$(PopupId + " .ButtonNow").click(function ()
					{
						var CurrentDate = new Date();
						CurrentHour = CurrentDate.getHours();
						CurrentMinute = CurrentDate.getMinutes();

						RenderTime();
						return Common.PrvntEvtPropg();
					});

					$(PopupId + " .ClickDecHour").click(function ()
					{
						CurrentHour += (CurrentHour == 0 ? 23 : -1);
						RenderTime();
						return Common.PrvntEvtPropg();
					});

					$(PopupId + " .ClickDecMinute").click(function ()
					{
						CurrentMinute += (CurrentMinute == 0 ? 59 : -1);
						RenderTime();
						return Common.PrvntEvtPropg();
					});

					$(PopupId + " .ClickIncHour").click(function ()
					{
						CurrentHour += (CurrentHour == 23 ? 0 : 1);
						RenderTime();
						return Common.PrvntEvtPropg();
					});

					$(PopupId + " .ClickIncMinute").click(function ()
					{
						CurrentMinute += (CurrentMinute == 59 ? 0 : 1);
						RenderTime();
						return Common.PrvntEvtPropg();
					});
				}
			};
		</script>
	`;