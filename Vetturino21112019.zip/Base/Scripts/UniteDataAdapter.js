function ClsDataAdapter()
{
	This = this;

	this.ExecuteQuery = function ()
	{
		var RetVal;
		var ScriptName = "UniteAjaxQuery.php";
		var Query = arguments[0];
		var Params = Array.prototype.slice.call(arguments, 1);
		var DirectUrl = Common.GetBaseUrl() + "Base/ServerScripts/" + ScriptName + "?Query=" + Query;

		for (Index = 0; Index < Params.length; Index++)
		{
			DirectUrl = DirectUrl + "&Params[]=" + Params[Index];
		}
		RetVal = This.GenericAjaxCall(ScriptName, { "Query": Query, "Params": Params });
		return RetVal;
	}

	this.ExecuteDynamicQuery = function ()
	{
		var RetVal;
		var ScriptName = "UniteAjaxDynamicQuery.php";
		var Query = arguments[0];
		var Params = Array.prototype.slice.call(arguments, 1);
		var DirectUrl = Common.GetBaseUrl() + "Base/ServerScripts/" + ScriptName + "?Query=" + Query;

		for (Index = 0; Index < Params.length; Index++)
		{
			DirectUrl = DirectUrl + "&Params[]=" + Params[Index];
		}
		RetVal = This.GenericAjaxCall(ScriptName, { "Query": Query, "Params": Params });
		return RetVal;
	}

	this.ExecutePhp = function ()
	{
		var RetVal;
		var ScriptName = arguments[0];
		var Params = Array.prototype.slice.call(arguments, 1);
		var DirectUrl = Common.GetBaseUrl() + "Base/ServerScripts/" + ScriptName + "?";

		for (Index = 0; Index < Params.length; Index++)
		{
			DirectUrl = DirectUrl + "Params[]=" + Params[Index] + "&";
		}
		DirectUrl = (DirectUrl.length > 1 ? DirectUrl.substr(0, DirectUrl.length - 1) : DirectUrl);
		RetVal = This.GenericAjaxCall(ScriptName, { "Params": Params });
		return RetVal;
	}

	this.ExportToExcel = function ()
	{
		var RetVal;
		var ScriptName = "UniteAjaxExportToExcel.php";
		var Query = arguments[0];
		var Params = Array.prototype.slice.call(arguments, 1);
		var DirectUrl = Common.GetBaseUrl() + "Base/ServerScripts/" + ScriptName + "?Query=" + Query;

		for (Index = 0; Index < Params.length; Index++)
		{
			DirectUrl = DirectUrl + "&Params[]=" + Params[Index];
		}
		RetVal = This.GenericAjaxCall(ScriptName, { "Query": Query, "Params": Params });
		return RetVal;
	}

	this.SendMail = function (MailTo, SenderName, Subject, Body, SmtpServer, SmtpPort, SmtpUser, SmtpPassword, SmtpSecure)
	{
		var RetVal;
		var ScriptName = "UniteAjaxSendMail.php";
		var DirectUrl = Common.GetBaseUrl() + "Base/ServerScripts/" + ScriptName + "?";

		DirectUrl += "MailTo=" + MailTo + "&SenderName=" + SenderName + "&Subject=" + Subject + "&Body=" + Body + "&SmtpServer=" + SmtpServer + "&SmtpPort=" + SmtpPort + "&SmtpUser=" + SmtpUser + "&SmtpPassword=" + SmtpPassword + "&SmtpSecure=" + SmtpSecure;
		RetVal = This.GenericAjaxCall(ScriptName, { "MailTo": MailTo, "SenderName": SenderName, "Subject": Subject, "Body": Body, "SmtpServer": SmtpServer, "SmtpPort": SmtpPort, "SmtpUser": SmtpUser, "SmtpPassword": SmtpPassword, "SmtpSecure": SmtpSecure });
		return RetVal;
	};

	this.SendSms = function (SmsToPhNo, SmsText)
	{
		var RetVal;
		var ScriptName = "UniteAjaxSendSms.php";
		var DirectUrl = Common.GetBaseUrl() + "Base/ServerScripts/" + ScriptName + "?";

		DirectUrl += "SmsToPhNo=" + SmsToPhNo + "&SmsText=" + SmsText;
		RetVal = This.GenericAjaxCall(ScriptName, { "SmsToPhNo": SmsToPhNo, "SmsText": SmsText });
		return RetVal;
	};

	this.GenericAjaxCall = function (ScriptName, Data)
	{
		var RetVal;

		$.ajax({
			url: "./Base/ServerScripts/" + ScriptName,
			data: Data,
			type: "POST",
			cache: false,
			async: false,
			dataType: "json",
			success: function (data, result)
			{
				RetVal = null;
				if (!result)
				{
					RetVal = {
						"HasError": true,
						"HasRows": false,
						"RowsAffected": 0,
						"InsertId": 0,
						"ErrorMessage": "Failure to retrieve Sync Data",
						"Data": ""
					};
				}
				else
				{
					RetVal = data;
				}
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				Debug("Ajax Error: " + jqXHR.responseText);
				RetVal = {
					"HasError": true,
					"HasRows": false,
					"RowsAffected": 0,
					"InsertId": 0,
					"ErrorMessage": jqXHR.responseText,
					"Data": ""
				};
			}
		});
		if (RetVal.HasError)
		{
			if (RetVal.ErrorMessage.StartsWith("Ajax Terminated: "))
			{
				UI.Alert("Info", RetVal.ErrorMessage.substr(17),
					function ()
					{
						location.href = "index.html";
					});
			}
			else
			{
				UI.Alert("Error", "Ajax Data Access Error!");
				Debug("Ajax Error: " + RetVal.ErrorMessage);
			}
		}
		return RetVal;
	}
}

//Instantiate An Object for the class
GlbServer = new ClsDataAdapter();

