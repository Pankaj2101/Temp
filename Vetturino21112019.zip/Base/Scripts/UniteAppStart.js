// Define all Global Variables 

var GlbServer;

var GlbPopupIndex = 0;

var GlbTableTagTotal = null;

var GlbTableTagType = null;

var GlbDebug = true;



// Application begins here

$(function ()

{

	Debug("Page Load Complete");

	$.ajaxSetup({ cache: false });				// Disable caching of AJAX responses



	// Load The application Title

	// ToDo: Must come from DB

	$(".AppTitle").html("<span class='SmartTransportFleet'>&nbsp;&nbsp;&nbsp;</span>");

	TmplMenuList = Handlebars.compile($("#TmplMenuList").html());					// Compile the Menu Template

	UI.UpdateMenu();																//ToDo: This should be done after login

	UI.BindDefaultButton();															//Bind and Setup some common UI handlers/events

	UI.BindMenuButton();

	//UI.BindScreenResize();

	UI.BindHashChange(LoadView);

	UI.BindDatePickerControls();

	



	//GlbTableTagType = GlbServer.ExecuteQuery("DADeviceTagTypeSelectAll").Data;	//Fetch Common Data to avoid server trips

	//GlbTableTagTotal = GlbServer.ExecuteQuery("DADeviceTagSelectAllCache").Data;



	UI.WaitHide();

	if (window.location.hash === "")

	{

		window.location.hash = "ViewDashboard.php";

	}

	else

	{

		LoadView();

	}

});



function LoadView()

{

	var GivenView = Common.CalledView();



	if (GivenView.Name !== "")

	{

		UI.MenuHide();

		//UI.UpdateMenu();

		$(".page-content").load("./Views/" + GivenView.Name + ".php",

            function ()

            {

                //On complettion of the load we should call the Init()

				CurrentView.Init();

				UI.HandleCounterup();

            }

		);

    }

}



function PrefetchStaticViews()

{

	var PrefetchViewObjs = [];





}

