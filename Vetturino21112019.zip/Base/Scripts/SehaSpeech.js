﻿// Idea borrowed from https://www.google.com/intl/en/chrome/demos/speech.html
// &             from https://codeburst.io/html5-speech-recognition-api-670846a50e92

function ClassSpeech(ListenerCallBack) 
{
	var This = this;

	this.Listener;
	this.ListenerFinalTranscript = "";			//FinalTranscript
	this.Listening = false;						//Recognizing
	this.ListenerCallBack = ListenerCallBack;
	this.ListenerIgnoreOnend;
	this.ListenerStart;

	var SpeakVoices =
		[
			{ lang: "en-US", name: "Microsoft David Desktop - English (United States)" },
			{ lang: "en-US", name: "Microsoft Zira Desktop - English (United States)" },
			{ lang: "de-DE", name: "Google Deutsch" },
			{ lang: "en-US", name: "Google US English" },
			{ lang: "en-GB", name: "Google UK English Female" },
			{ lang: "en-GB", name: "Google UK English Male" },
			{ lang: "es-ES", name: "Google español" },
			{ lang: "es-US", name: "Google español de Estados Unidos" },
			{ lang: "fr-FR", name: "Google français" },
			{ lang: "hi-IN", name: "Google हिन्दी" },
			{ lang: "id-ID", name: "Google Bahasa Indonesia" },
			{ lang: "it-IT", name: "Google italiano" },
			{ lang: "ja-JP", name: "Google 日本語" },
			{ lang: "ko-KR", name: "Google 한국의" },
			{ lang: "nl-NL", name: "Google Nederlands" },
			{ lang: "pl-PL", name: "Google polski" },
			{ lang: "pt-BR", name: "Google português do Brasil" },
			{ lang: "ru-RU", name: "Google русский" },
			{ lang: "zh-CN", name: "Google&nbsp;普通话（中国大陆）" },
			{ lang: "zh-HK", name: "Google&nbsp;粤語（香港）" },
			{ lang: "zh-TW", name: "Google 國語（臺灣）" }
		];
	this.Speak;
	this.SpeakVoicesAvailable = [];
	this.SpeakUtterance;

	this.VoiceCommands = {};

	this.Init = function ()
	{
		if (!("speechSynthesis" in window))
		{
			Common.LogMessage("Error", "Fatal Error! Browser does not support Speech!");
			return;
		}
		if (!("webkitSpeechRecognition" in window))
		{
			Common.LogMessage("Error", "Fatal Error! Browser does not support Speech!");
			return;
		}

		//Initialise Speaking capabilities
		This.Speak = window.speechSynthesis;
		This.SpeakVoicesAvailable = This.Speak.getVoices();
		if (This.Speak.onvoiceschanged !== undefined)
		{
			This.Speak.onvoiceschanged = This.Speak.getVoices();
		}
		Common.LogMessage("Info", "Speech Speaking Capability Initialised");

		//Initialise Listening capabilities
		This.Listener = new window.webkitSpeechRecognition; //window.SpeechRecognition;
		This.Listener.continuous = true;
		This.Listener.interimResults = true;
		This.Listener.lang = "en-IN";
		///To Do: This.Listener.grammars.addFromString("Seha");

		This.Listener.onresult = This.ListenerOnResult;
		This.Listener.onstart = This.ListenerOnStart;
		This.Listener.onend = This.ListenerOnEnd;
		This.Listener.onerror = This.ListenerOnError;

		This.ListenerStart = event.timeStamp;
		This.ListenerIgnoreOnend = false;
		if (This.Listening)
		{
			This.Listener.stop();
		}
		Common.LogMessage("Info", "Speech Initialised");
	}

	this.SpeakText = function (Text)
	{
		if (This.Speak.speaking)
		{
			console.error('speechSynthesis.speaking');
			return;
		}
		if (Text !== '')
		{
			This.ListenStop();

			This.SpeakUtterance = new SpeechSynthesisUtterance(Text);
			This.SpeakUtterance.onend = function (event)
			{
				console.log('SpeechSynthesisUtterance.onend');
				This.ListenStart();
			}
			This.SpeakUtterance.onerror = function (event)
			{
				console.error('SpeechSynthesisUtterance.onerror');
				This.ListenStart();
			}
			This.SpeakUtterance.pitch = 1;  // 0 to 2
			This.SpeakUtterance.rate = 1;  // 0.5 to 2
			This.SpeakUtterance.voice = This.SpeakVoicesAvailable.filter(function (voice) { return voice.name == "Google US English"; })[0];
			//This.SpeakUtterance.voice = This.SpeakVoicesAvailable.filter(function (voice) { return voice.name == "Google 日本語"; })[0];
			This.Speak.speak(This.SpeakUtterance);
		}
	};

	this.ListenStart = function ()
	{
		This.Listener.continuous = true;
		if (!This.Listening)
		{
			This.Listener.start();
		}
		$(".Mike").attr("class","Mike glow");
		console.log("start");
		Common.LogMessage("Info", "Speech Listener: Started");
	};

	this.ListenStop = function ()
	{
		This.Listener.continuous = false;
		This.Listener.stop();
		console.log("stop");
		$(".Mike").attr("class","Mike");
		Common.LogMessage("Info", "Speech Listener: Stopped");
	};

	this.ListenerOnResult = function (event) 
	{
		var InterimTranscript = "";

		if (typeof event.results === "undefined")
		{
			Common.LogMessage("Warning", "Speech Listener: Undefined Result");
			This.Listener.stop();
			return;
		}

		for (var Index = event.resultIndex; Index < event.results.length; Index += 1)
		{
			if (event.results[Index].isFinal)
			{
				This.ListenerFinalTranscript += event.results[Index][0].transcript;
			}
			else
			{
				This.ListenerInterimTranscript += event.results[Index][0].transcript;
			}
		}
		This.ListenerFinalTranscript = Common.Capitalize(This.ListenerFinalTranscript);

		if (This.ListenerFinalTranscript !== "")
		{
			Common.LogMessage("Info", "Speech Listener: Recognised: " + This.ListenerFinalTranscript);
			$(".TextBoxSend").val(Common.LineBreak(This.ListenerFinalTranscript));
			setTimeout(function ()
			{
				var e = jQuery.Event("keypress");
				e.which = 13; //choose the one you want
				e.keyCode = 13;
				$(".TextBoxSend").trigger(e);
			}, 1000);
			This.ListenerFinalTranscript = "";
		}
		else
		{
			Common.LogMessage("Warning", "Speech Listener: Empty result");
		}

		//		//interim_span.innerHTML = This.LineBreak(InterimTranscript);

		//		//if (FinalTranscript || InterimTranscript)
		//		//{
		//		//	showButtons("inline-block");
		//		//}
	};


	this.ListenerOnEnd = function (event) 
	{
		Common.LogMessage("Info", "Speech Listener: end event");
		This.Listening = false;

		if (This.Listener.continuous) 
		{
			Common.LogMessage("Info", "Speech Listener: Restarting");
			This.Listener.start();
		}
	};

	this.ListenerOnStart = function (event) 
	{
		Common.LogMessage("Info", "Speech Listener: Start ");
		This.Listening = true;
	};

	this.ListenerOnError = function (event) 
	{
		Common.LogMessage("Error", "Speech Listener: Error occured: " + event.error);
	};



	//Command functionalities
	//Not used in our implementation
	this.VoiceParseCommand = function (ListenerFinalTranscript)
	{
		var TheVoiceCommands = This.VoiceCommands;

		This.ConsoleLog("Speech Listener: Received Command: ", This.ListenerFinalTranscript);
		This.ListenerFinalTranscript = This.ListenerFinalTranscript.toLowerCase().trim();

		Object.keys(TheVoiceCommands).forEach(function (NextCommand)
		{
			if (This.ListenerFinalTranscript.indexOf(NextCommand) > -1)
			{
				if (This.ListenerFinalTranscript[NextCommand.length] === undefined)
				{
					This.ConsoleLog("Speech Listener: calling command", NextCommand);
					This.VoiceCommands[NextCommand]();
				}
				else if (This.ListenerFinalTranscript[NextCommand.length] === " ")
				{
					var Params = This.ListenerFinalTranscript.substring(NextCommand.length, This.ListenerFinalTranscript.length).trim();
					This.VoiceCommands[NextCommand](Params);

					This.ConsoleLog("Speech Listener: Calling command ", NextCommand, " with params: ", Params);
				}
			}
		});
	};

	this.VoiceAddCommand = function (Command, ListenerCallBack)
	{
		This.ConsoleLog("Speech Listener: Added Command:", Command);

		This.VoiceCommands[Command.toLowerCase()] = ListenerCallBack;
	};

	this.VoiceRemoveCommand = function (Command)
	{
		This.ConsoleLog("Speech Listener: Removed command:", Command);

		if (This.VoiceCommands[Command])
		{
			delete This.VoiceCommands[Command];
			return true;
		}

		return false;
	};

	this.VoiceGetCommand = function ()
	{
		var This2 = this;
		var Timeout = 1;

		if (This.IsRecognizing())
		{
			//Wait for one second if already recognising
			This.Stop();
			Timeout = 1000;
		}

		setTimeout(function ()
		{
			This.ConsoleLog("Speech Listener: Listening for single command");
			//This is important to make continous stop in case of single command getting
			This2.Listener.continuous = false;
			This2.Listener.start();
		}, Timeout);
	};

	this.VoiceParseSehaCommands = function (Transcript)
	{
		var ListenerFinalTranscript = Transcript;

		ListenerFinalTranscript = ListenerFinalTranscript.replace("Sia", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("See her", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("See ha", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("See ya", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("sia", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("see her", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("see ha", "Seha");
		ListenerFinalTranscript = ListenerFinalTranscript.replace("see ya", "Seha");
		return ListenerFinalTranscript;
	}

	This.Init();
};
