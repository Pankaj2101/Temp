<?php
	include "UniteCommon.php";

	$Params = (isset($_POST["Params"]) ? $_POST["Params"]: array());
	
	$TName = (isset($Params[0])? $Params[0]: "");
	$Month = (isset($Params[1])? $Params[1]: "");
	$Year = (isset($Params[2])? $Params[2]: "");
	
	$RetVal = 
        array(
			"Data" => "" 
		);
	
	if ($TName == "DeviceLog")
	{
		$RetVal["Data"] = ExportTable($DBUrl, $DBUser, $DBPassword, $DBName, $TName, "SELECT * FROM `$TName` WHERE MONTH(EventDate) = $Month AND YEAR(EventDate) = $Year ORDER BY Id");
	}
	else
	{
		$RetVal["Data"] = ExportTable($DBUrl, $DBUser, $DBPassword, $DBName, $TName, "SELECT * FROM `$TName` ORDER BY Id");
	}
	
    echo json_encode($RetVal);
    return;

	function &ExportTable($DBUrl, $DBUser, $DBPassword, $DBName, $Table, $Query)
	{
		$Data = "";
		$ConnMySql;
		$Rs;

		$ConnMySql = mysql_connect($DBUrl, $DBUser, $DBPassword);
		mysql_select_db($DBName, $ConnMySql);
		mysql_query( "SET NAMES `utf8` COLLATE `utf8_general_ci`", $ConnMySql ); // Unicode
		$Rs = mysql_query("SHOW CREATE TABLE `{$Table}`", $ConnMySql);
		$Rows = mysql_fetch_row($Rs);

		$Data .= "/*---------------------------------------------------------------" . "\r\n";
		$Data .= "SQL TABLE BACKUP " . date("d.m.Y H:i") . "\r\n";
		$Data .= "HOST: {$DBUrl}" . "\r\n";
		$Data .= "DATABASE: {$DBName}" . "\r\n";
		$Data .= "TABLE: {$Table}" . "\r\n\r\n";
		$Data .= "Data Query: {$Query}" . "\r\n\r\n";
		$Data .= "DROP TABLE IF EXISTS `{$Table}`;" . "\r\n\r\n";
		$Data.= $Rows[1] . ";\r\n";
		$Data .= "---------------------------------------------------------------*/" . "\r\n\r\n";

		$TableData = mysql_query($Query, $ConnMySql);
		$RowCount = mysql_num_rows($TableData);    

		$FinalRows = Array(); 
		for ($RowIndex = 0; $RowIndex < $RowCount; $RowIndex++)
		{
			$NextRow = mysql_fetch_row($TableData);
			$FinalRows[$RowIndex] = "(";
			for ($ColIndex = 0; $ColIndex < count($NextRow); $ColIndex++)
			{
				if (isset($NextRow[$ColIndex])) 
				{ 
					$FinalRows[$RowIndex].= "'" . mysql_real_escape_string( $NextRow[$ColIndex], $ConnMySql ) . "'"; 
				} 
				else 
				{ 
					$FinalRows[$RowIndex] .= "NULL"; 
				}
		
				if ($ColIndex < (count($NextRow) - 1))
				{ 
					$FinalRows[$RowIndex] .= ","; 
				}
			}
			$FinalRows[$RowIndex] .= ")"; 
		}
		
		if (count($FinalRows) > 0)
		{
			$Data .= "INSERT INTO `{$Table}` VALUES " . implode(";\r\nINSERT INTO `{$Table}` VALUES ", $FinalRows) . ";\r\n";
		}
		else
		{
			$Data .= "------------- No Data Found for the given criterion! ------------" . ";\r\n";
		}
		$Data .= "---------------------------------------------------------------" . "\r\n\r\n";

		mysql_close( $ConnMySql );
		
		//header("Content-Type: text/plain");
		//header("Content-Disposition: attachment; filename='$Table" . date("Ydm-Hi") . ".Sql'");
		//header("Content-Length: " . strlen($Data));
		//echo $Data;
		$FileName = "./Downloads/" . $Table . "_" . date("YmdHis") . ".sql";
	    file_put_contents("../" . $FileName, $Data . PHP_EOL);
	
		return $FileName;
	}
?>