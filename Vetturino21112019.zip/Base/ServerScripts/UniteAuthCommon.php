<?php

//Session, Navigation & Permissions Related functions

// Expected Session Variables
// SessionID;
// UserId;
// UnitId;

// UnitName;
// CompanyId;
// CompanyName;
// FormName;
// UserName;

function IsAdmin()
{
    return (strtolower(GetSessVar("UserId")) == "admin");
}

function GetSessVar($GivenVar)
{
    if (isset($_SESSION[$GivenVar]))
    {
        return $_SESSION[$GivenVar];
    }
    return "";
}

function SetSessVar($GivenVar, $Value)
{
    $_SESSION[$GivenVar] = $Value;
}


function CheckSessionExpiry($Direct = false)
{
    $TimeOutInSeconds = 600; // 10 minutes
    if(!isset($_SESSION))
    {
        session_start();
    }
    if (
            GetSessVar("LastActivity") != "" && 
            GetSessVar("UserId") != "" && 
            GetSessVar("SessionId") != "" && 
            GetSessVar("SessionId") == session_id() && 
            (time() - GetSessVar("LastActivity") < $TimeOutInSeconds)
        ) 
    {
        SetSessVar("LastActivity", time()); // update last activity time stamp
    }
    else
    {
        if ($Direct == true)
        {
            session_unset();     // unset $_SESSION variable for the run-time 
            session_destroy();   // destroy session data in storage
            header('Location:index.html?RCode=1'); //Invalid Access!
        }
        else
        {
            AjaxTerminate("Ajax Terminated: Session Expired! Your session has expired due to prolonged inactivity!<br>You are being redirected to login page. $Direct = '" . $Direct . ";");
        }
    }
}

function AjaxTerminate($Message)
{
    // last request was more than 30 minutes ago
    session_unset();     // unset $_SESSION variable for the run-time 
    session_destroy();   // destroy session data in storage
    $RetVal = 
    array(
        "Data" => array(), 
        "ErrorMessage" => $Message, 
        "HasError" => true, 
        "HasRows" => false, 
        "RowsAffected" => 0, 
        "InsertId" => 0, 
        "ParsedQuery" => "", 
        "SessionId" => session_id(), 
        "ExecutionTime" => 0
        );
    return json_encode($RetVal);
}

function AuthenticateLogin()
{
    global $Queries;

    //This is a hard coded file only for login validation and does not have session checking
    $Ip = GetIp();
    $Params = (isset($_REQUEST["Params"]) ? $_REQUEST["Params"]: array());
    $User = (isset($Params[0]) ? $Params[0]: "");
    $Pass = (isset($Params[1]) ? $Params[1]: "");
    $RetVal = array(
                        "Data" => array(), 
                        "ErrorMessage" => "Invalid Credentials!", 
                        "HasError" => true, 
                    );

    $LoginSuccess = false;
    $Ds = new ExDataSet($Queries["DAfw_UserInfo"], $User);
    if ($Ds->HasError)
    {
        $RetVal["ErrorMessage"] = $Ds->Error; //Important do not move this line below the next query the error will be overwritten
        $Ds = new ExDataSet($Queries["DAfw_InsertLoginInfo"], $User, $Ip, 0);
    }
    else if (!$Ds->HasRows)
    {
        $RetVal["ErrorMessage"] = "Invalid Credentials!";
        $Ds = new ExDataSet($Queries["DAfw_InsertLoginInfo"], $User, $Ip, 0);
    }
    else
    {
        if ($Ds->GetData(0, "Password") == $Pass)
        {
            session_start();
            SetSessVar("LastActivity", time());
            SetSessVar("UserId", $User);
            SetSessVar("UserName", $Ds->GetData(0, "Name"));
            SetSessVar("SessionId", session_id());
            SetSessVar("CompIp", $Ip);

            $RetVal["Data"] = $Ds->Rows;
            $RetVal["HasRows"] = $Ds->HasRows;
            $RetVal["HasError"] = false;
            $RetVal["ErrorMessage"] = "";

            $Ds->ExecQuery($Queries["DAfw_InsertLoginInfo"], $User, $Ip, 1);
            $Ds->UpdateLastUserAccessTime();
        }
        else
        {
            $Ds = new ExDataSet($Queries["DAfw_InsertLoginInfo"], $User, $Ip, 0);
        }
    }
    return json_encode($RetVal);
}

function GetAuthorisedUnits()
{
    global $Queries;
    $RetHtmlUnits = "[{'Id': '-1', 'Name': 'No Units Authorised!', 'LastUsed': '1'}]";
    $RetHtmlMenus = "";
    $Query = $Queries[(IsAdmin() ? "DAfwGetUnitsForAdmin" : "DAfwGetUnitsForUser")];
    $Ds = new ExDataSet($Query, GetSessVar("UserId"));
    if (!$Ds->HasError && $Ds->HasRows)
    {
        $RetHtmlUnits = json_encode($Ds->Rows);

        //Loop and get the last used unitid
        $SelectedUnitId = $Ds->Rows[0]["Id"];
        foreach($Ds->Rows as $Index=>$NextRow)
        {
            if ($NextRow["LastUsed"] == 1)
            {
                $SelectedUnitId = $Ds->Rows[$Index]["Id"];
                break;
            }
        }
        SetSessVar("UnitId", $SelectedUnitId);
        $RetHtmlMenus = GetAuthorisedMenus($SelectedUnitId);
    }
    return $RetHtmlUnits;
}

function GetAuthorisedMenus($GivenUnit = '')
{
    global $Queries;
    $RetHtml = "[]";

    if ($GivenUnit != '')
    {
        SetSessVar("UnitId", $GivenUnit);
    }
    $Ds = new ExDataSet($Queries["DAfwUpdateUnitLastUsed"], GetSessVar("UnitId"), GetSessVar("UserId"));

    $Query = $Queries[(IsAdmin() ? "DAfw_GetMenusForAdmin" : "DAfw_GetMenusForUser")];
    $Ds = new ExDataSet($Query, GetSessVar("UserId"), GetSessVar("UnitId"));
    if (!$Ds->HasError && $Ds->HasRows)
    {
        $RetHtml = json_encode($Ds->Rows);
    }
    return $RetHtml;
}

function AuthenticatePageAccess($GivenFormName)
{
    CheckSessionExpiry();
    global $Queries;

    if (!IsAdmin())
    {
        $Ds = new ExDataSet($Queries["DAfw_CheckIfFormAuthorised"], GetSessVar("UnitId"), GetSessVar("UserId"));
        if ($Ds->HasError || !$Ds->HasRows)
        {
            echo "<div class='UnauthorisedAccess'>Invalid Link Access!</div>";
            echo "<script>";
            echo "    function ClsViewDashboard() { this.Init = function (Params) {} }";
            echo "    var CurrentView = new ClsViewDashboard();";
            echo "</script>";
            die;
        }
    }
}

?>