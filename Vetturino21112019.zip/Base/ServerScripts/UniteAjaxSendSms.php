<?php
    include (dirname(__FILE__) . "/UniteCommon.php");
    CheckSessionExpiry();

	//Local Variables Setup and initialisation
	$RetVal = 
	    array(
		    "Data" => array(), 
		    "ErrorMessage" => "", 
		    "HasError" => false 
		    );

	//Convert all named parameters to local variables
	$SmsToPhNo    = (isset($_REQUEST["SmsToPhNo"])?    $_REQUEST["SmsToPhNo"]: "");
	$SmsText      = (isset($_REQUEST["SmsText"])?      $_REQUEST["SmsText"]: "");

	$RetVal = array();
	try
	{
		$Status = file("http://smsnmms.co.in/sms.aspx?Id=$GWUserId&Pwd=$GWPassword&PhNo=$SmsToPhNo&text=$SmsText");
		$RetVal["Data"] = $Status[0];

		if (strpos($Status[0], "Message Submitted") == FALSE)
		{
			$RetVal["HasError"] = false;
			$RetVal["ErrorMessage"] = $Status[0];
		}
	}
	catch (Exception $e)
	{
		$RetVal["HasError"] = true;
		$RetVal["ErrorMessage"] = $e->getMessage();
	}

	echo json_encode($RetVal);
	return;
?>