<?php
    include (dirname(__FILE__) . "/UniteCommon.php");
    CheckSessionExpiry();

	require(dirname(__FILE__) . "/PhpMailer/class.phpmailer.php");

	//Local Variables Setup and initialisation
	$RetVal = 
	array(
		"Data" => array(), 
		"ErrorMessage" => "", 
		"HasError" => false
		);
		
	//Convert all named parameters to local variables
	$MailTo       = (isset($_REQUEST["MailTo"])?       $_REQUEST["MailTo"]: "");
	$SenderName   = (isset($_REQUEST["SenderName"])?   $_REQUEST["SenderName"]: $DefaultMailSenderName);
	$Subject      = (isset($_REQUEST["Subject"])?      $_REQUEST["Subject"]: "");
	$Body         = (isset($_REQUEST["Body"])?         $_REQUEST["Body"]: "");
	$SmtpServer   = (isset($_REQUEST["SmtpServer"])?   $_REQUEST["SmtpServer"]: $DefaultMailSmtpServer);
	$SmtpPort     = (isset($_REQUEST["SmtpPort"])?     $_REQUEST["SmtpPort"]: $DefaultMailSmtpPort);
	$SmtpUser     = (isset($_REQUEST["SmtpUser"])?     $_REQUEST["SmtpUser"]: $DefaultMailSmtpUser);
	$SmtpPassword = (isset($_REQUEST["SmtpPassword"])? $_REQUEST["SmtpPassword"]: $DefaultMailSmtpPassword);
	$SmtpSecure   = (isset($_REQUEST["SmtpSecure"])?   $_REQUEST["SmtpSecure"]: "");
	$SenderName   = ($SenderName != "" ? $SenderName: $DefaultMailSenderName);
	$SmtpServer   = ($SenderName != "" ? $SmtpServer: $DefaultMailSmtpServer);
	$SmtpPort     = ($SenderName != "" ? $SmtpPort: $DefaultMailSmtpPort);
	$SmtpUser     = ($SenderName != "" ? $SmtpUser: $DefaultMailSmtpUser);
	$SmtpPassword = ($SenderName != "" ? $SmtpPassword: $DefaultMailSmtpPassword);

	try
	{
		$Data = array();

		//Send Mail From Here
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true; 
		$mail->SMTPSecure = $SmtpSecure; 
		$mail->Port = $SmtpPort;  
		$mail->Host = gethostbyname($SmtpServer);
		$mail->Username = $SmtpUser;  
		$mail->Password = $SmtpPassword;
		$mail->SetFrom($SmtpUser, $SenderName);
		$mail->Subject = $Subject;
		$mail->Body = $Body;
		$Addresses = explode(',', $MailTo);
		foreach ($Addresses as $Address) 
		{
			$mail->AddAddress($Address);
		}
		//$mail->AddAddress($MailTo);

		$mail->IsHTML(true);

		$RetVal["Data"] = $Data;
		if(!$mail->Send()) 
		{
			$RetVal["HasError"] = true;
			$RetVal["ErrorMessage"] = $mail->ErrorInfo;
		}
	}
	catch (Exception $e)
	{
		$RetVal["HasError"] = true;
		$RetVal["ErrorMessage"] = $e->getMessage();
	}

	echo json_encode($RetVal);
	return;
?>