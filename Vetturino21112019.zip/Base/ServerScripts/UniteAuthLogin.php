<?php
session_start();
session_unset(); 
session_destroy(); 

include (dirname(__FILE__) . "/UniteCommon.php");
echo AuthenticateLogin();
?>