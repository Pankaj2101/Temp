<?php
include (dirname(__FILE__) . "/UniteCommon.php");
CheckSessionExpiry();

try
{
    global $Queries;
    $Params       = (isset($_REQUEST["Params"]) ?      $_REQUEST["Params"]: array());
    $Query = $Queries[(IsAdmin() ? "DAfw_GetMenusForAdmin" : "DAfw_GetMenusForUser")];
    $Ds = new ExDataSet($Query, GetSessVar("UserId"), $Params[0]);
    $RetVal["UnitId"] = $Params[0];
    $RetVal["query"] = $Ds->QueryParsed; 
    $RetVal["Data"] = $Ds->Rows;
    $RetVal["HasRows"] = $Ds->HasRows;
    $RetVal["RowsAffected"] = $Ds->RowsCount;
    $RetVal["InsertId"] = $Ds->InsertId; 
    if (strtolower(GetSessVar("UserId")) == "admin")
    {
        $RetVal["Query"] = $Ds->QueryParsed;
    }
}
catch (Exception $e)
{
    $RetVal["HasError"] = true;
    $RetVal["ErrorMessage"] = $e->getMessage();
}

echo json_encode($RetVal);
return;
?>