<?php
    include (dirname(__FILE__) . "/UniteCommon.php");
    //CheckSessionExpiry();

	//Local Variables Setup and initialisation
	$Ip = GetIp();
	$RetVal = 
	array(
		"Data" => array(), 
		"ErrorMessage" => "", 
		"HasError" => false, 
		"HasRows" => false, 
		"RowsAffected" => 0
		);

	//Convert all named parameters to local variables
	$Query        = (isset($_REQUEST["Query"])?        $_REQUEST["Query"]: "");
	$Params       = (isset($_REQUEST["Params"]) ?      $_REQUEST["Params"]: array());

	try
	{
        //Update Last Access for User
        $Ds = new ExDataSet();
        $Ds->UpdateLastUserAccessTime();
        $Ds->ExecQuery($Queries[$Query], ...$Params);
		$ExportFile = ConvertDsToExcel($Ds, $Params[count($Params)-1]);
			
		$RetVal["Data"] = $ExportFile;
		$RetVal["HasRows"] = $Ds->HasRows; 
		$RetVal["RowsAffected"] = $Ds->RowsCount;
        if (strtolower(GetSessVar("UserId")) == "admin")
        {
            $RetVal["Query"] = $Ds->QueryParsed;
        }
        //Insert Into Log
        $Ds->LogNoSelectQuery($Ds->QueryParsed);
	}
	catch (Exception $e)
	{
		$RetVal["HasError"] = true;
		$RetVal["ErrorMessage"] = $e->getMessage();
	}
	$Data = "";

	echo json_encode($RetVal);
	return;

    function ConvertDsToExcel($Ds, $Header)
    {
        try
        {
            $ExportFile = uniqid("Rpt", true) . ".xls";
            $ExportFileWithPath = dirname(__FILE__) . "/../../Downloads/" . $ExportFile;

            $fp = fopen($ExportFileWithPath, 'w');
            fwrite($fp, "");
            fwrite($fp, "<style>
			tr {border: 1px dotted darkgreen;} 
			td {border: 1px dotted #353535; 
			text-align: right;width: 100px;} 
			td.Header{text-align: right; background-color: #333333; border: 1px dotted gray; font-weight:bold; color: white}
			</style>");
            fwrite($fp, "<table>");
            fwrite($fp, $Header);

            foreach($Ds->Rows as $NextRow)
            {
                fwrite($fp, "<tr class='DataList'>");
                foreach($NextRow as $Col => $Value)
                {
                    fwrite($fp, "<td class='DataList'>" . $Value . "</td>");
                }
                fwrite($fp, "</tr>");
            }
            
            fwrite($fp, "</table>");
            fclose($fp);
            return $ExportFile;
        }
        catch(Exception $e)
        {
            throw new Exception("Error creatig report file. " . $e->getMessage());
        }

    }
?>