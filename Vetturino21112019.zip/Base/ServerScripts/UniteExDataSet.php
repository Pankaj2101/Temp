<?php
/*
//Test & Usage    
$DBName = "uniteslick";		
$DBUrl = "localhost";		
$DBUser = "useruniteslick";			
$DBPassword = "TOrv]FCyvqW0";

//Both of these methods work
$Ds = new ExDataSet("SELECT * FROM fw_users WHERE Id < %%Param1%% ORDER BY %%Param2%%", 5, "Name");
//$Ds = new ExDataSet("SELECT * FROM fw_users WHERE Id < %%Param1%% ORDER BY %%Param2%%", ...array(5, "Name");
echo print_r($Ds->Rows);
echo "<br>";
echo $Ds->GetData(0, "Name");
echo $Ds->Error;
*/ 


class ExDataSet
{
    private $QueryRaw;
    private $ConnIsOpen = false;
    private $Rs;
    public $QueryParsed;
    public $ConnMySql;

    public $Rows = array();
    public $RowsCount = 0;
    public $InsertId = 0;
    public $Error = "";
    public $HasError = false;
    public $HasRows = false;
    
    function __construct($QueryRaw = "", ...$Params) 
    {
        try
        {
            $this->DbConnect();
            if ($QueryRaw != "")
            {
                $this->ExecQuery($QueryRaw, ...$Params);
            }
        }
        catch(Exception $e)
        {
            throw new Exception($e->getMessage());
        }
    }

    public function DbConnect()
    {
        global $DBUrl, $DBUser, $DBPassword, $DBName;
        
        try
        {
            // Create a connection object by connecting to the database
            $this->ConnMySql = new mysqli($DBUrl, $DBUser, $DBPassword, $DBName);
            if (!$DBUrl || !$DBUser || !$DBPassword || !$DBName)
            {
                throw new Exception("Failed to connect to MySQL!<br>Invalid credentials."); 
            }
            if ($this->ConnMySql->connect_errno) 
            {
                if ($this->ConnMySql->connect_errno == 1045)
                {
                    throw new Exception("Failed to connect to MySQL!<br>Invalid credentials.<br>Error: (" . $this->ConnMySql->connect_errno . ") - Access denied for given user (using password: YES)"); 
                }
                else
                {
                    throw new Exception("Failed to connect to MySQL!<br>Error: (" . $this->ConnMySql->connect_errno . ") - "  . mysqli_connect_error()); 
                }
            }
            $this->ConnIsOpen = true;
        }
        catch(Exception $e)
        {
            $this->ConnIsOpen = false;
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }

    public function DbGetRecords()
    {
        try
        {
            $this->Rs = @mysqli_query($this->ConnMySql, $this->QueryParsed);
            if (!$this->Rs)
            {
                throw new Exception("Failed to execute query!<br>Error: (" . $this->ConnMySql->errno . ") - "  . $this->ConnMySql->error . "<br>ParsedQuery: '" . $this->QueryParsed . "'"); 
                $this->Rs = null;
            }
        }
        catch(Exception $e)
        {
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }

    public function DbGetDataSet()
    {
        try
        {
            $this->Rows = array();
            while ($Row = @mysqli_fetch_assoc($this->Rs))
            {
                $this->Rows[] = $Row;
            }
            $this->RowsCount = count($this->Rows);
            $this->HasRows = ($this->RowsCount > 0);
            $this->InsertId = mysqli_insert_id($this->ConnMySql);
        }
        catch(Exception $e)
        {
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }

    public function ExecQuery($QueryRaw, ...$GivenParams) 
    {
        try
        {
            $this->ParseQuery($QueryRaw, ...$GivenParams);  
            $this->DbGetRecords();
            $this->DbGetDataSet();
        }
        catch(Exception $e)
        {
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }

    public function UpdateLastUserAccessTime()
    {
        $this->ExecQuery("UPDATE fw_users SET LastAccessed = GetIst() WHERE Userid = '%%Param1%%'", GetSessVar("UserId"));
    }

    public function LogNoSelectQuery($GivenQuery)
    {
		if (strtoupper(substr(trim($GivenQuery), 0, 6)) != "SELECT")
		{
            $Ds1 = new ExDataSet();
            $Ds1->ExecQuery("INSERT INTO fw_eventslog (EventDate, CallingIP, UserID, Description) VALUES (GetIst(), '" . GetIp() . "', '" . GetSessVar("UserId") . "', 'Non-Select Query Called: " . $this->EscapeString($GivenQuery) . "');");
        }
    }

    public function GetData($RowNo, $GivenField) 
    {
        try
        {
            if ($this->RowsCount > 0)
            {
                return $this->Rows[$RowNo][$GivenField];
            }
            else
            {
                return "";
            }
        }
        catch(Exception $e)
        {
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }

    public function ParseQuery($QueryRaw, ...$Params)
    {
        try
        {
            $this->RawQuery = trim($QueryRaw);
            $QueryParsed = $this->RawQuery;
            $Index = 1;
            foreach ($Params as $NextParam)
            {
                $QueryParsed = str_replace("%%Param".($Index)."%%", str_replace("<Apostrophe>", "'", str_replace("'", "\'", $NextParam)), $QueryParsed);
                $Index++;
            }
            $QueryParsed = str_replace("%%Param0%%", GetSessVar("UserId"), $QueryParsed);
            $this->QueryParsed = trim($QueryParsed);
        }
        catch(Exception $e)
        {
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }

    public function EscapeString($GivenString)
    {
        try
        {
            return mysqli_real_escape_string($this->ConnMySql, $GivenString);
        }
        catch(Exception $e)
        {
            $this->HasError = true;
            $this->Error = $e->getMessage();
            throw new Exception($e->getMessage());
        }
    }
}

?>