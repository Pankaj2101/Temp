<?php
//Array of Global Queries - Note this is an associative array of named queries 
$BaseQueries = array
(
    ////////////////////////////////////////////////////
    //Validate user on login and get his/her details
    ////////////////////////////////////////////////////
    "FWDA_ValidateUser" => 
    "SELECT 
            * 
        FROM 
            fw_users 
        WHERE 
            UserId = '%%Param1%%' 
            AND Password = '%%Param2%%'
            AND NOT InActive",
        
    ////////////////////////////////////////////////////
    //GetTable Schema for automatic script development
    ////////////////////////////////////////////////////
    "FWDA_GetSchema" =>
    "SELECT
			Column_Name, Data_Type, Column_Comment
		FROM
			INFORMATION_SCHEMA.COLUMNS
		WHERE
			TABLE_SCHEMA = '%%Param1%%'
			AND TABLE_NAME = '%%Param2%%'
			AND Column_Name <> 'Id' 
			AND Column_Name <> 'Modified' 
			AND Column_Name <> 'InActive'",

    "DAfw_unitsSelectAllCount" => 
    "SELECT
			COUNT(*) AS TotalRecords
		FROM
			fw_units
		WHERE
			UnitId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR CompanyId LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%' OR TermsConditions LIKE '%%%Param1%%%'",

    "DAfw_unitsSelectAll" => 
    "SELECT
			Id, UnitId, Name, CompanyId, Address, City, PinCode, Email, Phones, PanNo, GstNo, TermsConditions, InActive
		FROM
			fw_units
		WHERE
			UnitId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR CompanyId LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%' OR TermsConditions LIKE '%%%Param1%%%'
		ORDER BY
			%%Param2%% %%Param3%%
		LIMIT %%Param4%%, %%Param5%%",

    "DAfw_unitsSelect" => 
    "SELECT
			Id, UnitId, Name, CompanyId, Address, City, PinCode, Email, Phones, PanNo, GstNo, TermsConditions, InActive
		FROM
			fw_units
		WHERE
			Id = '%%Param1%%'",

    "DAfw_unitsDelete" => 
    "UPDATE
			fw_units
		SET
			InActive = 1,  ModifiedOn = GetIst(), ModifiedBy = '%%Param0%%', IsSynched = 0
		WHERE
			Id = '%%Param1%%'",

    "DAfw_unitsInsert" => 
    "INSERT INTO fw_units
			(UnitId, Name, CompanyId, Address, City, PinCode, Email, Phones, PanNo, GstNo, TermsConditions, InActive, ModifiedOn, ModifiedBy, IsSynched)
		VALUES 
			('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', '%%Param11%%', '%%Param12%%', GetIst(), '%%Param0%%', 0)",

    "DAfw_unitsUpdate" => 
    "UPDATE 
			fw_units
		SET 
			UnitId = '%%Param1%%', Name = '%%Param2%%', CompanyId = '%%Param3%%', Address = '%%Param4%%', City = '%%Param5%%', PinCode = '%%Param6%%', Email = '%%Param7%%', Phones = '%%Param8%%', PanNo = '%%Param9%%', GstNo = '%%Param10%%', TermsConditions = '%%Param11%%', InActive = '%%Param12%%', ModifiedOn = GetIst(), ModifiedBy = '%%Param0%%', IsSynched = 0
		WHERE 
			Id = '%%Param13%%'",

    "DAfw_companiesSelectAllCount" => 
    "SELECT
			COUNT(*) AS TotalRecords
		FROM
			fw_companies
		WHERE
			CompanyId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR WebSite LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%'",

    "DAfw_companiesSelectAll" => 
    "SELECT
			Id, CompanyId, Name, Address, City, PinCode, WebSite, Email, Phones, PanNo, GstNo, InActive
		FROM
			fw_companies
		WHERE
			CompanyId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR WebSite LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%'
		ORDER BY
			%%Param2%% %%Param3%%
		LIMIT %%Param4%%, %%Param5%%",

    "DAfw_companiesSelect" => 
    "SELECT
			Id, CompanyId, Name, Address, City, PinCode, WebSite, Email, Phones, PanNo, GstNo, InActive
		FROM
			fw_companies
		WHERE
			Id = '%%Param1%%'",

    "DAfw_companiesDelete" => 
    "UPDATE
			fw_companies
		SET
			InActive = 1,  ModifiedOn = GetIst(), ModifiedBy = '%%Param0%%', IsSynched = 0
		WHERE
			Id = '%%Param1%%'",

    "DAfw_companiesInsert" => 
    "INSERT INTO fw_companies
			(CompanyId, Name, Address, City, PinCode, WebSite, Email, Phones, PanNo, GstNo, InActive, ModifiedOn, ModifiedBy, IsSynched)
		VALUES 
			('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', '%%Param11%%', GetIst(), '%%Param0%%', 0)",

    "DAfw_companiesUpdate" => 
    "UPDATE 
			fw_companies
		SET 
			CompanyId = '%%Param1%%', Name = '%%Param2%%', Address = '%%Param3%%', City = '%%Param4%%', PinCode = '%%Param5%%', WebSite = '%%Param6%%', Email = '%%Param7%%', Phones = '%%Param8%%', PanNo = '%%Param9%%', GstNo = '%%Param10%%', InActive = '%%Param11%%', ModifiedOn = GetIst(), ModifiedBy = '%%Param0%%', IsSynched = 0
		WHERE 
			Id = '%%Param12%%'",

    "DAfwUpdateUnitLastUsed" => 
    "UPDATE 
            fw_unitrights 
        SET 
            LastUsed = IF(UnitId = '%%Param1%%', 1, 0) 
        WHERE
            UserId = '%%Param2%%'",

    "DAfwGetUnitsForAdmin" => 
    "SELECT DISTINCT
            U.UnitId AS Id, CONCAT(U.UnitId, ' - ', C.Name, ', ', U.Name) AS Name, 
            CASE WHEN U.Id = (SELECT Min(Id) FROM fw_units) THEN 1 ELSE 0 END AS LastUsed
        FROM 
            fw_units AS U,
            fw_companies AS C
        WHERE 
            U.CompanyId = C.CompanyId 
        ORDER BY 
            U.Name",

    "DAfwGetUnitsForUser" => 
    "SELECT DISTINCT
            U.UnitId AS Id, CONCAT(U.UnitId, ' - ', C.Name, ', ', U.Name) AS Name, R.LastUsed
        FROM 
            fw_units AS U, 
            fw_companies AS C,
            fw_unitrights AS R 
        WHERE 
            U.CompanyId = C.CompanyId 
            AND U.UnitId = R.UnitId 
            AND R.UserId = '%%Param1%%'
        ORDER BY 
            C.Name, U.Name",

    "DAfw_GetMenusForAdmin" => 
    "SELECT  
            M.*
        FROM 
            fw_menus AS M 
        ORDER BY 
            M.GroupOrder, M.MenuOrder",

    "DAfw_GetMenusForUser" => 
    "SELECT
            M.*
        FROM 
            fw_menus AS M, 
            fw_menurights AS MIR 
        WHERE 
            MIR.MenuId = M.MenuId 
            AND MIR.UserId = '%%Param1%%' 
            AND MIR.UnitId = '%%Param2%%'  
        ORDER BY 
            M.GroupOrder, M.MenuOrder",

    "DAfw_CheckIfFormAuthorised" => 
    "SELECT 
            M.FormName
        FROM 
	        fw_menurights AS R,
            fw_menus AS M
        WHERE 
            R.UnitId = '%%Param1%%'
	        AND R.UserId = '%%Param2%%'
            AND M.FormName = 'ViewDashBoard.php'
            AND R.MenuId = M.MenuId",

    "DAfw_UserInfo" => 
    "SELECT 
            * 
        FROM 
            fw_users 
        WHERE 
            UserId ='%%Param1%%' 
            AND NOT InActive",


    "DAfw_InsertLoginInfo" => 
    "INSERT INTO 
            fw_logininfo 
            (UserId, LoginTime, IP, Success) 
        VALUES 
            ('%%Param1%%', GetIst(), '%%Param2%%', '%%Param3%%')"

    //Special Queries and Views etc.
    /*
    UPDATE Vrmaster 
    SET  VrNoOld =  CONCAT(mid(VrNoOld, 3, 8), "-", RIGHT(CONCAT("0", RIGHT(VrNoOld, CHAR_LENGTH(VrNoOld) - 10)), 5), "-", LEFT(VrNoOld, 1)) 

    INSERT INTO VrMaster
    (VrNo) 
    SELECT 
    MAX(vrno) + 1 
    FROM VrMaster;
    */
);

?>