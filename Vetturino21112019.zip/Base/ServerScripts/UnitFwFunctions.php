<?php

    $UrlPrefix = IsLocal() ? "http://localhost/trade": "http://trade.technodune.com";

    $AutoMailBodyFormat = "<html><body style='font-family: Arial; font-size: 10pt; color: Navy' ><br /><table style='font-family: Arial; font-size: 8pt; wIdth: 100%; border:solId 1px silver;' cellspacing='0' cellpadding='0'><tr><td colspan='2' style=' font-size: 10pt; font-weight:bold; border: solId 1px silver; background-color: silver ' >Detailed Information</td></tr><tr><td style=' border: solId 1px silver;' align='left'>%%Param1%%</td></tr></table></body></html>";
    $StdMailBodyFormat = "<html><body style='font-family: Arial; font-size: 10pt; color: Navy' >%%Param1%%</body></html>";
    $InputMapper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_";
    $OutputMapper = "X4A2FVIQJU0K_L8CMETNHWOB9PG7RSZ1D35Y6";

    // Infline Queries for framework
    $ILQSelectLastUsedUnitBranch = "SELECT TOP 1 LastUsedUnitId, LastUsedBranchId FROM fw_NavUser WHERE UserId = '%%Param1%%'";
    $ILQUpdateUsedUnitBranch = "UPDATE fw_NavUser SET LastUsedUnitId = '%%Param1%%', LastUsedBranchId = '%%Param2%%' WHERE UserId = '%%Param3%%'";
    $ILQCheckUserAccess = "SELECT * FROM fw_NavMenuItemRights WHERE UserId = '%%Param1%%' AND BranchId = '%%Param2%%' AND MenuItemId = '%%Param3%%'";
    $ILQFunctionalAccessDelete = "DELETE FROM fw_FunctionalAccessRights WHERE UserId ='%%Param1%%' AND FAId = (SELECT FAId FROM fw_FunctionalAccess WHERE FunctionAccess = '%%Param2%%')";
    $ILQFunctionalAccessInsert = "INSERT (UserId, FAId) VALUES ('%%Param1%%, (SELECT FAId FROM fw_FunctionalAccess WHERE FunctionAccess = '%%Param2%%'))";
    $ILQFunctionalAccessSelect = "SELECT TOP 1 FROM fw_FunctionalAccessRights WHERE UserId ='%%Param1%%' AND FAId = (SELECT FAId FROM fw_FunctionalAccess WHERE FunctionAccess = '%%Param2%%')";
    $ILQGetAdminBranches = "SELECT DISTINCT BranchId, BranchName FROM fw_NavBranch WHERE UnitId = '%%Param2%%' ORDER BY BranchName";
    $ILQGetAdminMenuItems = "SELECT  Module, Menu, MenuOrder, MenuItemId, MenuItem, FormName FROM fw_NavMenuItem  ORDER BY Module, Menu, MenuOrder, MenuItemId";
    $ILQGetAdminMenus = "SELECT DISTINCT Menu FROM fw_NavMenuItem WHERE Module = '%%Param1%%' ORDER BY Menu";
    $ILQGetAdminModules = "SELECT DISTINCT Module FROM fw_NavMenuItem ORDER BY Module";
    $ILQGetAdminUnits = "SELECT DISTINCT UnitId, UnitName FROM fw_NavUnit ORDER BY UnitName";
    $ILQGetUserBranches = "SELECT DISTINCT B.BranchId, B.BranchName FROM fw_NavUnit AS U, fw_NavBranch AS B, fw_NavBranchRights AS R WHERE U.UnitId = B.UnitId AND B.BranchId = R.BranchId AND R.UserId = '%%Param1%%' AND B.UnitId = '%%Param2%%' ORDER BY B.BranchName";
    $ILQGetUserMenuItems = "SELECT Module, Menu, MenuOrder, MenuItem, MIR.MenuItemId, FormName FROM fw_NavMenuItem AS M, fw_NavMenuItemRights AS MIR WHERE MIR.MenuItemId = M.MenuItemId AND MIR.UserId = '%%Param1%%' AND MIR.BranchId = '%%Param2%%'  ORDER BY Module, Menu, MenuOrder, M.MenuItemId";
    $ILQGetUserMenus = "SELECT DISTINCT Menu FROM fw_NavMenuItem AS M, fw_NavMenuItemRights AS UMR WHERE UMR.MenuId = M.MenuId AND B.BranchId = UMR.BranchId AND U.UnitId = B.UnitId AND Module = '%%Param1%%'  AND UMR.UserId = '%%Param2%%' AND B.BranchId = '%%Param3%%' ORDER BY Menu";
    $ILQGetUserModules = "SSELECT DISTINCT Module FROM fw_NavMenuItem AS M, fw_NavBranch AS B, fw_NavUnit AS U, fw_NavMenuItemRights AS UMR WHERE UMR.MenuItemId = M.MenuItemId AND B.BranchId = UMR.BranchId AND U.UnitId = B.UnitId AND UMR.UserId = '%%Param1%%' AND B.BranchId = '%%Param2%%' ORDER BY Module";
    $ILQGetUserUnits = "SELECT DISTINCT U.UnitId, U.UnitName, R.UserId  FROM fw_NavUnit AS U, fw_NavBranch AS B, fw_NavBranchRights AS R WHERE U.UnitId = B.UnitId AND B.BranchId = R.BranchId AND R.UserId = '%%Param1%%' ORDER BY U.UnitName";
    $ILQInsertLoginInfo = "INSERT INTO fw_LoginInfo(UserId, LoggedIN,IP,ComputerName,Success) values ('%%Param1%%','%%Param2%%','%%Param3%%','%%Param4%%','%%Param5%%')";
    $ILQMenusSelect = "SELECT ISNULL(ParentId, 0) AS ParentId, MenuId, MenuName, Description, FormName, MenuOrder FROM fw_NavMenuItem WHERE MenuId IN (SELECT MenuId FROM fw_NavMenuItemRights WHERE(UserId = '%%Param1%%' AND UnitId ='%%Param2%%' AND BranchId ='%%Param3%%')) ORDER BY ParentId, MenuOrder";
    $ILQMenusSelectAll = "SELECT ISNULL(ParentId, 0) AS ParentId, MenuId, MenuName, Description, FormName, MenuOrder FROM fw_NavMenuItem ORDER BY ParentId, MenuOrder";
    $ILQSelectPassForAdmin = "SELECT Password AS Password, UserId AS Id FROM fw_NavUser WHERE UserId = 'Admin'";
    $ILQUserRecordSelect = "SELECT * FROM fw_NavUser  WHERE UserId ='%%Param1%%'";
    $ILQDashBoardLogins ="SELECT TOP 5 * FROM fw_LoginInfo WHERE UserName = '%%Param1%%' ORDER BY LoggedIN DESC";
    $ILQUDashBoardMessages = "SELECT TOP 5 M.*, MT.* FROM fw_Messages M, fw_MessageTrans MT  WHERE(M.MsgRowId = MT.MsgRowId) AND MT.ToUser ='%%Param1%%' AND MT.Readon is Null ORDER BY M.DateMsg DESC";

    //******************************************
    // Returns dencrypted & utf8-encoded
    // Usage: 
    // define("ENCRYPTION_KEY", "!@#$%^&*");
    // $string = "This is the original data string!";
    // echo $encrypted = UtEncrypt($string, ENCRYPTION_KEY);
    //******************************************
    function UtEncrypt($pure_string, $encryption_key) 
    {
        $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $encrypted_string = mcrypt_encrypt(MCRYPT_BLOWFISH, $encryption_key, utf8_encode($pure_string), MCRYPT_MODE_ECB, $iv);
        return $encrypted_string;
    }

    //******************************************
    // Returns decrypted original string
    // Usage: 
    // define("ENCRYPTION_KEY", "!@#$%^&*");
    // $string = "This is the original data string!";
    // echo $decrypted = UtDecrypt(UtEncrypt($string, ENCRYPTION_KEY), ENCRYPTION_KEY);
    //******************************************
    function UtDecrypt($encrypted_string, $encryption_key) 
    {
        $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $decrypted_string = mcrypt_decrypt(MCRYPT_BLOWFISH, $encryption_key, $encrypted_string, MCRYPT_MODE_ECB, $iv);
        return $decrypted_string;
    }

    function UtToIndianAmount($GivenNumber)
    {
        $RetVal = "";
        $NumberAsString = "";
        $GivenNumber = (float)$GivenNumber;
        if ($GivenNumber < 0)
        {
            $GivenNumber = -$GivenNumber;
        }
        if ($GivenNumber == 0)
        {
            return " NIL ";
        }
        $NumberAsString = "000000000.00" . number_format($GivenNumber, 2, ".", "");
        $NumberAsString = substr($NumberAsString, -12);
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 0, 2), "", " Crores ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 2, 2), "", " Lac ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 4, 2), "", " Thousand ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 6, 1), "", " Hundred ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 7, 2), "", "");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 10, 2), " & Paisa ", "");
        return ("Rs. " . $RetVal . " Only");
    }

    function UtToIndianNumber($GivenNumber)
    {
        $RetVal = "";
        $NumberAsString = "";
        $GivenNumber = (float)$GivenNumber;
        if ($GivenNumber < 0)
        {
            $GivenNumber = -$GivenNumber;
        }
        if ($GivenNumber == 0)
        {
            return " NIL ";
        }
        $NumberAsString = "000000000.00" . number_format($GivenNumber, 2, ".", "");
        $NumberAsString = substr($NumberAsString, -12);
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 0, 2), "", " Crores ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 2, 2), "", " Lac ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 4, 2), "", " Thousand ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 6, 1), "", " Hundred ");
        $RetVal = $RetVal . PartNumberToWord(substr($NumberAsString, 7, 2), "", "");
        return $RetVal;
    }

    function PartNumberToWord($GivenNumber, $Prefix, $Suffix)
    {
        $NumberWordArray = array ( "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Ninteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four", "Twenty Five", "Twenty Six", "Twenty Seven", "Twenty Eight", "Twenty Nine", "Thirty", "Thirty One", "Thirty Two", "Thirty Three", "Thirty Four", "Thirty Five", "Thirty Six", "Thirty Seven", "Thirty Eight", "Thirty Nine", "Forty", "Forty One", "Forty Two", "Forty Three", "Forty Four", "Forty Five", "Forty Six", "Forty Seven", "Forty Eight", "Forty Nine", "Fifty", "Fifty One", "Fifty Two", "Fifty Three", "Fifty Four", "Fifty Five", "Fifty Six", "Fifty Seven", "Fifty Eight", "Fifty Nine", "Sixty", "Sixty One", "Sixty Two", "Sixty Three", "Sixty Four", "Sixty Five", "Sixty Six", "Sixty Seven", "Sixty Eight", "Sixty Nine", "Seventy", "Seventy One", "Seventy Two", "Seventy Three", "Seventy Four", "Seventy Five", "Seventy Six", "Seventy Seven", "Seventy Eight", "Seventy Nine", "Eighty", "Eighty One", "Eighty Two", "Eighty Three", "Eighty Four", "Eighty Five", "Eighty Six", "Eighty Seven", "Eighty Eight", "Eighty Nine", "Ninty", "Ninty One", "Ninty Two", "Ninty Three", "Ninty Four", "Ninty Five", "Ninty Six", "Ninty Seven", "Ninty Eight", "Ninty Nine" );
        $Temp = $GivenNumber;
        $Temp = intval($Temp);
        if ($Temp <= 0)
        {
            return "";
        }
        return ($Prefix . $NumberWordArray[$Temp] . $Suffix);
    }
?>