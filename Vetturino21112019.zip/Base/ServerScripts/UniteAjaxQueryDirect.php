<?php
    include (dirname(__FILE__) . "/UniteCommon.php");
    //CheckSessionExpiry();

	//Local Variables Setup and initialisation
	$Ip = GetIp();
	$RetVal = 
	array(
		"Data" => array(), 
		"ErrorMessage" => "", 
		"HasError" => false, 
		"HasRows" => false, 
		"RowsAffected" => 0, 
		"InsertId" => 0 
		);

	//Convert all named parameters to local variables
	$Query        = (isset($_REQUEST["Query"])?        $_REQUEST["Query"]: "");
	$Params       = (isset($_REQUEST["Params"]) ?      $_REQUEST["Params"]: array());

    try
    {

        //Update Last Access for User
        $Ds = new ExDataSet();
        $Ds->UpdateLastUserAccessTime();
        $Ds->ExecQuery($Queries[$Query], ...$Params);
        $RetVal["Data"] = $Ds->Rows;
        $RetVal["HasRows"] = $Ds->HasRows;
        $RetVal["RowsAffected"] = $Ds->RowsCount;
        $RetVal["InsertId"] = $Ds->InsertId; 
        if (strtolower(GetSessVar("UserId")) == "admin")
        {
            $RetVal["Query"] = $Ds->QueryParsed;
        }
        //Insert Into Log
        $Ds->LogNoSelectQuery($Ds->QueryParsed);
    }
    catch (Exception $e)
    {
        $RetVal["HasError"] = true;
        $RetVal["ErrorMessage"] = $e->getMessage();
    }

	echo json_encode($RetVal);
	return;
?>