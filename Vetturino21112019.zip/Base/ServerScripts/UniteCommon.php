<?php

include (dirname(__FILE__) . "/UniteExDataSet.php");
include (dirname(__FILE__) . "/UniteQueries.php");
include (dirname(__FILE__) . "/UniteAuthCommon.php");
include (dirname(__FILE__) . "/../../ServerScripts/UniteCredentials.php");
include (dirname(__FILE__) . "/../../ServerScripts/UniteQueries.php");

//Merge Base Queries and User Queries
$Queries = array_merge($BaseQueries, $UserQueries);

//Start:- (Prachi Dabi)
function IsPresent(...$Params)
{
    $ValidFlag = TRUE;
    foreach($Params as $parameter)
    {
        if(!isset($_REQUEST[$parameter]))
        {
            $ValidFlag = FALSE;
        }
    }
    return $ValidFlag;
}
//END

function NowSql()
{
    return date("Y-m-d H:i:s.u");
}

function IsLocal()
{
    $Ip = $_SERVER["REMOTE_ADDR"];
    return ($Ip == "127.0.0.1" || $Ip == "::1" || StartsWith($Ip,"192.168.") || StartsWith($Ip,"10.") || StartsWith($Ip,"172.16."));
}

function GetIp()
{
    $RetIp = "";
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) 
    {
        $RetIp = $_SERVER['HTTP_CLIENT_IP'];
    } 
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
    {
        $RetIp = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } 
    else 
    {
        $RetIp = $_SERVER['REMOTE_ADDR'];
    }
    return $RetIp;
}

function StartsWith($TotalString, $StartString)
{
    $Length = strlen($StartString);
    return (substr($TotalString, 0, $Length) === $StartString);
}

function EndsWith($TotalString, $StartString)
{
    $Length = strlen($StartString);
    if ($Length == 0)
    {
        return true;
    }

    return (substr($TotalString, -$Length) === $StartString);
}

function ParseQuery($Query, $Params)
{
    $Index = 0;
    $ParsedQuery = trim($Query);
    for ($Index = 0; $Index < count($Params); $Index++)
    {
        $ParsedQuery = str_replace("%%Param".($Index)."%%", str_replace("<Apostrophe>", "'", str_replace("'", "\'", $Params[$Index])), $ParsedQuery);
    }
    return trim($ParsedQuery);
}

function WriteToLog($Title, $Description)
{
    file_put_contents(dirname(__FILE__) . "/../../Logs/log_" . date('Ymd') . ".txt", date("H:i:s." . substr((string)microtime(), 1, 8)) . 
    " - [" . GetIp() . "] - [" . $Title . "] - [" . $Description . "]" . PHP_EOL, FILE_APPEND);
}

function Debug($Text)
{
    echo ((string)$Text) . "<br>";
}

function WriteToXls($GivenFile, $GivenContent)
{
    file_put_contents($GivenFile, $GivenContent . PHP_EOL, FILE_APPEND);
    return;
}

function GetCurrentTime()
{
    $MicroTime = microtime(); 
    $MicroTime = explode(" ", $MicroTime); 
    $MicroTime = $MicroTime[1] + $MicroTime[0]; 
    return $MicroTime; 
}

function GUID() //Simple Function to get a GUID
{
    if (function_exists('com_create_guid') === true)
    {
        return trim(com_create_guid(), '{}');
    }

    return sprintf(
        '%04X%04X-%04X-%04X-%04X-%04X%04X%04X', 
        mt_rand(0, 65535), 
        mt_rand(0, 65535), 
        mt_rand(0, 65535), 
        mt_rand(16384, 20479), 
        mt_rand(32768, 49151), 
        mt_rand(0, 65535), 
        mt_rand(0, 65535), 
        mt_rand(0, 65535)
        );
}

function ReadGlobalVars()
{
    //$Url = (isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "");
    //SetSessVar("FormName", substr($Url, strpos($Url, "#") + 1));

    if (GetSessVar("AppSettingsRead") != "true")
    {
        //Read Global Config Values
        $Ds = new ExDataSet("SELECT * FROM fw_config ");
        $RowIndex = 0;
        while ($RowIndex < $Ds->RowsCount)
        {
            SetSessVar($Ds->GetData($RowIndex, "ConfigId"), $Ds->GetData($RowIndex, "Value"));
            $RowIndex++;
        }

        SetSessVar("AppSettingsRead", true);
    }
}

?>