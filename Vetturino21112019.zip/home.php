﻿<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<?php
	include (dirname(__FILE__) . "/./Base/ServerScripts/UniteCommon.php");
	CheckSessionExpiry(true);
	ReadGlobalVars();
	echo "<script type='text/javascript'>"; 
	echo "var AuthorisedUnits = " . GetAuthorisedUnits() . ";";
	echo "var AuthorisedMenus = " . GetAuthorisedMenus() . ";";
	echo "</script>"; 
?>
<head>
	<meta charset="utf-8" />
	<title>Slick | Enterprise IoT Application Framework</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<!-- GLOBAL STYLES -->
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/font-awesome/css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/simple-line-icons/simple-line-icons.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap-switch/css/bootstrap-switch.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/select2/css/select2-bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/select2/css/select2.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/morris/morris.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/fullcalendar/fullcalendar.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/jqvmap/jqvmap/jqvmap.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap-daterangepicker/daterangepicker.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" />								  s
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap-timepicker/css/bootstrap-timepicker.min.css" />									  s
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" />								  s
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/clockface/css/clockface.css" />	
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/typeahead/typeahead.css"/>
	<link rel="stylesheet" type="text/css" href="./Base/assets/scripts/bootstrap-toastr/toastr.min.css">
	<link rel="stylesheet" type="text/css" href="./Base/assets/css/components.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/css/plugins.min.css" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/css/layout.css"/>
	<link rel="stylesheet" type="text/css" href="./Base/assets/css/themes/darkblue.css" id="style_color" />
	<link rel="stylesheet" type="text/css" href="./Base/assets/css/custom.css" />
	<!-- UNITE STYLES -->
	<link rel="stylesheet" type="text/css" href="./Styles/Custom.css" />
	<link rel="stylesheet" type="text/css" href="./Styles/Callout.css" />
	<link rel="shortcut icon" href="./Images/ShortLogo.png" />
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
	<div class="page-wrapper">
		<!-- BEGIN HEADER -->
		<div class="page-header navbar navbar-fixed-top">
			<!-- BEGIN HEADER INNER -->
			<div class="page-header-inner ">
				<!-- BEGIN LOGO -->
				<div class="page-logo">
					<div class="menu-toggler sidebar-toggler">
						<span></span>
					</div>
					<!-- BEGIN RESPONSIVE MENU TOGGLER -->
					<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
						<span></span>
					</a>
					<!-- END RESPONSIVE MENU TOGGLER -->
					<a href="index.html">
						<img src="./Images/VetturinoDeviceNewLogoSmall.png" alt="logo" class="logo-default" />
					</a>
					<!-- BEGIN APPLICATION TITLE -->
					<div class="AppTitle">
					</div>
					<!-- END APPLICATION TITLE -->
				</div>
				<!-- END LOGO -->
				<!-- BEGIN TOP NAVIGATION MENU -->
				<div class="top-menu">
					<ul class="nav navbar-nav pull-right">
						<!-- BEGIN NOTIFICATION DROPDOWN -->
						<!-- END NOTIFICATION DROPDOWN -->
						<!-- BEGIN INBOX DROPDOWN -->
						<!-- END INBOX DROPDOWN -->
						<!-- BEGIN TODO DROPDOWN -->
						<!-- END TODO DROPDOWN -->
						<!-- BEGIN USER LOGIN DROPDOWN -->
						<!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
						<li class="dropdown dropdown-user">
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
								<img alt="" class="img-circle" src="./Base/assets/img/avatar3_small.jpg" />
								<span class="username username-hide-on-mobile"><?php echo(GetSessVar("UserId")); ?></span>
								<i class="fa fa-angle-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-default">
								<li>
									<a href="#">
										<i class="icon-user"></i> My Profile
									</a>
								</li>
								<li>
									<a href="./">
										<i class="icon-key"></i> Log Out
									</a>
								</li>
							</ul>
						</li>
						<!-- END USER LOGIN DROPDOWN -->
						<!-- BEGIN QUICK SIDEBAR TOGGLER -->
						<!-- END QUICK SIDEBAR TOGGLER -->
					</ul>
				</div>
				<!-- END TOP NAVIGATION MENU -->
			</div>
			<!-- END HEADER INNER -->
		</div>
		<!-- END HEADER -->
		<!-- BEGIN HEADER & CONTENT DIVIDER -->
		<div class="clearfix"> </div>
		<!-- END HEADER & CONTENT DIVIDER -->
		<!-- BEGIN CONTAINER -->
		<div class="page-container">
			<!-- BEGIN SIDEBAR -->
			<div class="page-sidebar-wrapper">
				<!-- BEGIN SIDEBAR -->
				<!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
				<!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
				<div class="page-sidebar navbar-collapse collapse">
					<!-- BEGIN SIDEBAR MENU -->
					<!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
					<!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
					<!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
					<!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
					<!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
					<!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
					<ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
						<!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
						<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
						<!-- END SIDEBAR TOGGLER BUTTON -->
						<!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
					</ul>
					<!-- END SIDEBAR MENU -->
				</div>
				<!-- END SIDEBAR -->
			</div>
			<!-- END SIDEBAR -->
			<!-- BEGIN CONTENT -->
			<div class="page-content-wrapper">
				<!-- BEGIN CONTENT BODY -->
				<div class="page-content">
				</div>
				<!-- END CONTENT BODY -->
			</div>
			<!-- END CONTENT -->
		</div>
		<!-- END CONTAINER -->
		<!-- BEGIN FOOTER -->
		<div class="page-footer">
			<div class="page-footer-inner">
				2017 &copy; Powered By <a target="_blank" href="http://TechMahindra.com`">
					Tech Mahindra Limited
				</a>
			</div>
			<div class="scroll-to-top">
				<i class="icon-arrow-up"></i>
			</div>
		</div>
		<!-- END FOOTER -->
	</div>

	<div class="CalloutBody callout right" style="width: 400px; height: 180px; left: 511px; top: 100px; display: none;">	
		<div class="calloutCloseBtn"></div>	
		<div class="content" style="width: 100%; height: 100%;">
			<p style="font-size: 20px;text-align: center;padding: 6px;margin-bottom: 0px;">May all beings everywhere be happy and free, and may the thoughts, words, and actions of my own life contribute in some way to that happiness and to that freedom for all</p>
		</div>
	</div>

	<!-- THIRD PARTY SCRIPTS -->
	<script type="text/javascript" src="./Base/assets/scripts/jquery.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/js.cookie.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/jquery.blockui.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/app.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/select2/js/select2.full.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/jquery.blockui.min.js"></script>
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPDIBsvAjwFHHSm9E2zpogzfU-_CWzykI&v=3.exp&libraries=drawing&callback=initMap"></script>
	<script type="text/javascript" src="https://cdn.rawgit.com/googlemaps/v3-utility-library/master/markerwithlabel/src/markerwithlabel.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/moment.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootstrap-daterangepicker/daterangepicker.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
    <script type="text/javascript" src="./Base/assets/scripts/bootstrap-toastr/toastr.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/clockface/js/clockface.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/bootbox/bootbox.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/counterup/jquery.counterup.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/counterup/jquery.waypoints.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/components-date-time-pickers.min.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/flot/jquery.flot.min.js"></script>
    <script type="text/javascript" src="./Base/assets/scripts/flot/jquery.flot.resize.min.js"></script>
    <script type="text/javascript" src="./Base/assets/scripts/flot/jquery.flot.categories.min.js"></script>
    <script type="text/javascript" src="./Base/assets/scripts/flot/jquery.flot.curvedlines.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/jquery-easypiechart/jquery.easypiechart.min.js"></script>
    <script type="text/javascript" src="./Base/assets/scripts/jquery.sparkline.min.js"></script>
	<script type="text/javascript" src="./Base/Scripts/handlebars.js"></script>
	<script type="text/javascript" src="./Base/Scripts/Chart.bundle.js"></script>
	<script type="text/javascript" src="./Base/assets/scripts/layout.min.js"></script>
	<!-- UNITE SCRIPTS -->
	<script type="text/javascript" src="./Base/Scripts/UniteTts.js"></script>
	<script type="text/javascript" src="./Base/Scripts/UniteCommon.js"></script>
	<script type="text/javascript" src="./Base/Scripts/UniteDataAdapter.js"></script>
	<script type="text/javascript" src="./Base/Scripts/UniteDateTimeFunctions.js"></script>
	<script type="text/javascript" src="./Base/Scripts/UniteCache.js"></script>
	<script type="text/javascript" src="./Base/Scripts/UniteUIHandlers.js"></script>
	<script type="text/javascript" src="./Base/Scripts/UniteAppStart.js"></script>
	<!-- HANDLEBARS MENU TEMPLATE -->
	<script type="text/x-handlebars-template" id="TmplMenuList">
		{{#Menus}}
		<li class="parent-menu nav-item {{#if IsOpen}} active open {{/if}} {{#if HasSubMenu}} HasSubMenu {{/if}}">
			<a href="#{{Link}}" class="nav-link nav-toggle">
				<i class="{{IconClass}}"></i>
				<span class="title">{{Title}}</span>
				{{#if HasSubMenu}}<span class="arrow {{#if IsOpen}} open {{else}} left {{/if}}"></span>{{/if}}
			</a>
			{{#if HasSubMenu}}
			<ul class="sub-menu">
				{{#SubMenu}}
				<li class="nav-item {{#if IsOpen}} active open {{/if}}">
					<a href="#{{Link}}" class="nav-link  nav-toggle">
						<i class="{{IconClass}}"></i>
						<span class="title">{{Title}}</span>
					</a>
				</li>
				{{/SubMenu}}
			</ul>
			{{/if}}
		</li>
		{{/Menus}}
	</script>
	</body>
</html>