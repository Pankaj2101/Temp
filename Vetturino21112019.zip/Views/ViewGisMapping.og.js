﻿function ClsViewGisMapping()
{
	var This = this;

	this.Initialised = false;
	this.Map;
	this.MapContainer = "#map";
	this.TagObjects = [];
	this.MapMode = "RoadMap";
	this.TagTypePicker = new ClsCheckListPicker();

	this.Init = function (Params)
	{
		//Setting up title and menu management
		UI.MenuHide();
		UI.SetPageTitle("GIS View: " + Cache.Get("SelectedTagTypeId"));

		This.InitialiseMap();

		This.TagTypePicker.Init(".ButtonTagType", "SingleSelect", "Select Device Type", GlbTableTagType, Cache.Get("SelectedTagTypeId"), function (ButtonClicked, SelectedItemIds, SelectedItemNames)
		{
			if (ButtonClicked == "Ok")
			{
				if (Cache.Get("SelectedTagTypeId") != SelectedItemIds)
				{
					Cache.Set("SelectedTagTypeId", SelectedItemIds);
					Cache.Set("SelectedTagTypeName", SelectedItemNames);
					This.Populate(true);
				}
			}
		});

		$(".ButtonMapType").click(function ()
		{
			if (This.MapMode == "RoadMap")
			{
				$(".ButtonMapType").html("n <span class='Icomatic'>Satellite View</span>");
				This.MapMode = "Satellite";
				This.Map.setMapTypeId(google.maps.MapTypeId.HYBRID);
			}
			else
			{
				$(".ButtonMapType").html("n <span class='Icomatic'>Street View</span>");
				This.MapMode = "RoadMap";
				This.Map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
			}
			This.Populate(true);
		});

		if (Params != null)
		{
			Cache.Get("SelectedTagTypeId", Params.Type);
			Cache.Get("SelectedTagTypeName", Params.Type);
		}

		This.Initialised = true;
		if (Cache.Get("SelectedTagTypeId") != "" && Cache.Get("SelectedTagIds").length > 0)
		{
			This.Populate(true);
		}
		else
		{
			$(".ButtonTagType").click();
		}
	};

	this.ToNum = function (GivenValue)
	{
		return (isNaN(GivenValue) ? 0 : GivenValue)
	};

	this.ToDash = function (GivenValue)
	{
		return (GivenValue == 0 ? "-" : GivenValue)
	};

	this.Populate = function (CompleteRefresh)
	{
		var RetVal;
		var IsVolume = (Cache.Get("SelectedTagTypeId") == "Volume");
		var Markers;

		if (!This.Initialised) return;

		UI.WaitShow("Loading...", function ()
		{
			//First remove any exisitng markers from the map
			for (var NextMarkerIndex = 0; NextMarkerIndex < This.TagObjects.length; NextMarkerIndex++)
			{
				This.TagObjects[NextMarkerIndex].Marker.setMap(null);
			}

			// Get Data from Database
			RetVal = GlbServer.ExecuteQuery("DAGisViewOfDevicesData", Cache.Get("SelectedTagTypeId"));

			//We need to scale and Process Data
			RetVal.Data = Common.ScaleAndProcessDataForGis(RetVal.Data);
RetVal.Data =
[
{"Name":"", "Location":"Scheme 2", "DataValues":"<b>6</b> Meters", "Latitude":"27.5711272", "Longitude":"76.6157072", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"HKM Nagar", "DataValues":"<b>5</b> Meters", "Latitude":"27.600300", "Longitude":"76.613815", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Kala Kua ", "DataValues":"<b>5</b> Meters", "Latitude":"27.54565", "Longitude":"76.5988683333333", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Malviya Nagar", "DataValues":"<b>4</b> Meters", "Latitude":"27.5327466666666", "Longitude":"76.6116033333333", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Manu Marg", "DataValues":"<b>4</b> Meters", "Latitude":"27.5599916", "Longitude":"76.6069533", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Scheme 10 ", "DataValues":"<b>4</b> Meters", "Latitude":"27.5774333333333", "Longitude":"76.61332", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Ladiya Park", "DataValues":"<b>3</b> Meters", "Latitude":"27.5665599999999", "Longitude":"76.59468", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Scheme 8", "DataValues":"<b>2</b> Meters", "Latitude":"27.5423929", "Longitude":"76.6084403", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Shvaji Park ", "DataValues":"<b>2</b> Meters", "Latitude":"27.591335", "Longitude":"76.6188933333333", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Bank Colony", "DataValues":"<b>2</b> Meters", "Latitude":"27.5569913", "Longitude":"76.6205028", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Munshi Bagh", "DataValues":"<b>2</b> Meters", "Latitude":"27.570257", "Longitude":"76.599002", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Ranjeet Nagar ", "DataValues":"<b>1</b> Meters", "Latitude":"27.5788233333333", "Longitude":"76.6318533333333", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Scheme 4", "DataValues":"<b>1</b> Meters", "Latitude":"27.5733898", "Longitude":"76.6040269", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Shanti Kunj", "DataValues":"<b>1</b> Meters", "Latitude":"27.53411", "Longitude":"76.6177166666666", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Subhash Nagar", "DataValues":"<b>1</b> Meters", "Latitude":"27.56743", "Longitude":"76.6257825", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"NEB Sector 4", "DataValues":"<b>1</b> Meters", "Latitude":"27.5632161", "Longitude":"76.6326229", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Ashok vihar", "DataValues":"<b>1</b> Meters", "Latitude":"27.5845901", "Longitude":"76.6199974", "Icon":"Images/flowmetericon.png"},
{"Name":"", "Location":"Tulera", "DataValues":"<b>1</b> Meters", "Latitude":"27.611068", "Longitude":"76.640428", "Icon":"Images/flowmetericon.png"}
]; //Only for temp workks


			for (var NextTagIndex = 0; NextTagIndex < RetVal.Data.length; NextTagIndex++)
			{
				var NextTagObject = {};
				var NextMarker = new MarkerWithLabel
				({
					map: This.Map,
					position: new google.maps.LatLng(RetVal.Data[NextTagIndex].Latitude, RetVal.Data[NextTagIndex].Longitude),
					icon: RetVal.Data[NextTagIndex].Icon,
					//shadow: pinShadow,
					labelContent: "<center><u>" + RetVal.Data[NextTagIndex].Location + "</u><br>" + RetVal.Data[NextTagIndex].DataValues + "</center>" ,
					labelAnchor: new google.maps.Point(12, -5),
					labelClass: "GoogleMapLabels",
					zIndex: 1
				});

				NextTagObject.Tag = RetVal.Data[NextTagIndex].Tag;
				NextTagObject.Marker = NextMarker;
				This.TagObjects.push(NextTagObject);
				google.maps.event.addListener(NextMarker, "mouseover", function (e)
				{
					console.log('mouseover');
					this.set("labelClass", "GoogleMapLabelsHovered")
					this.set("zIndex", 100)
				});
				google.maps.event.addListener(NextMarker, "mouseout", function (e)
				{
					console.log('mouseout');
					this.set("labelClass", "GoogleMapLabels")
					this.set("zIndex", 1)
				});
			}

			//if (IsVolume)	//Special Processing for Volume Data
			//{
			//	for (var Index = (RetVal.Data.length - 1) ; Index > 0 ; Index--)
			//	{
			//		RetVal.Data[Index].Values1 = This.ToDash(This.ToNum(RetVal.Data[Index].Values1) - This.ToNum(RetVal.Data[Index - 1].Values1));
			//		RetVal.Data[Index].Values2 = This.ToDash(This.ToNum(RetVal.Data[Index].Values2) - This.ToNum(RetVal.Data[Index - 1].Values2));
			//		RetVal.Data[Index].Values3 = This.ToDash(This.ToNum(RetVal.Data[Index].Values3) - This.ToNum(RetVal.Data[Index - 1].Values3));
			//		RetVal.Data[Index].Values4 = This.ToDash(This.ToNum(RetVal.Data[Index].Values4) - This.ToNum(RetVal.Data[Index - 1].Values4));
			//		RetVal.Data[Index].Values5 = This.ToDash(This.ToNum(RetVal.Data[Index].Values5) - This.ToNum(RetVal.Data[Index - 1].Values5));
			//		RetVal.Data[Index].Values6 = This.ToDash(This.ToNum(RetVal.Data[Index].Values6) - This.ToNum(RetVal.Data[Index - 1].Values6));
			//		RetVal.Data[Index].Values7 = This.ToDash(This.ToNum(RetVal.Data[Index].Values7) - This.ToNum(RetVal.Data[Index - 1].Values7));
			//		RetVal.Data[Index].Values8 = This.ToDash(This.ToNum(RetVal.Data[Index].Values8) - This.ToNum(RetVal.Data[Index - 1].Values8));
			//		RetVal.Data[Index].Values9 = This.ToDash(This.ToNum(RetVal.Data[Index].Values9) - This.ToNum(RetVal.Data[Index - 1].Values9));
			//		RetVal.Data[Index].Values10 = This.ToDash(This.ToNum(RetVal.Data[Index].Values10) - This.ToNum(RetVal.Data[Index - 1].Values10));
			//	}
			//	RetVal.Data[0].Values1 = "-";
			//	RetVal.Data[0].Values2 = "-";
			//	RetVal.Data[0].Values3 = "-";
			//	RetVal.Data[0].Values4 = "-";
			//	RetVal.Data[0].Values5 = "-";
			//	RetVal.Data[0].Values6 = "-";
			//	RetVal.Data[0].Values7 = "-";
			//	RetVal.Data[0].Values8 = "-";
			//	RetVal.Data[0].Values9 = "-";
			//	RetVal.Data[0].Values10 = "-";
			//}

			UI.WaitHide();
		});

	};

	this.InitialiseMap = function ()
	{
		//var MapStartLocation = [26.9161724, 75.7893562];
		var MapStartLocation = [27.551878, 76.634283]; //Temporay Change for alwar
		var MapDrawManager;

		// Define the map and its starting Options
		This.Map = new google.maps.Map($(This.MapContainer)[0],
            {
            	zoom: 14,
            	center: new google.maps.LatLng(MapStartLocation[0], MapStartLocation[1]),
            	mapTypeId: google.maps.MapTypeId.ROADMAP,
            	disableDefaultUI: true,
            	zoomControl: true
            });

		// Define the drawing manager to draw markers and polylines etc.
		MapDrawManager = new google.maps.drawing.DrawingManager(
            {
            	map: This.Map,
            	drawingControl: false,
            	drawingMode: null,
            });

		// Add event handler for 'Hand' button
		/*google.maps.event.addDomListener($(".ButtonHand")[0], "click", function ()
		{
			HighlightButton(this);

			//Deselect current object if any
			DeselectCurrentObject();
			MapDrawManager.setDrawingMode(null);

			//Set global editor properties
			EditorMode = "None";
			EditorObjectType = "None";
			EditorSelectedObject = null;
		});
		*/
	};
}

function DisplayCoordinates(GivenCoordinates)
{
	$('.TextCoordinates').html(GivenCoordinates);
	//ToDo: Update the new location in database
}

function RedrawExistingObjects()
{
	//First clear all old data which has not been modified from ou
	$.each(CurrentObjects, function (Key, NextObject)
	{
		if (!NextObject.IsNewObject && !NextObject.HasModified)
		{
			delete NextObject;
		}
	});

	//Finally Get The Data from Database to draw the saved Objects
	var RetObjects = GetData("CurrentUser", "ExtentStart1", "ExtentStart2");

	//Now add basic items to each object
	$.each(RetObjects, function (key, NextObject)
	{
		NextObject.IsNewObject = false;
		NextObject.HasModified = false;
	});

	CurrentData = RetObjects;
	$.each(RetObjects, function (key, NextObject)
	{
		if (NextObject.Type == "Marker")
		{
			NextObject.Object
		}
		else
		{

		}
	});
}

//Instantiate An Object for the class
var ViewGisMapping = new ClsViewGisMapping();
