<?php
    //ValidateAccess();
?>

<div class="SubHeader">
    <h1 class="topcoat-navigation-bar__title" style="display: inline"></h1>
</div>
<div class="UtListContainer" style="overflow-x: auto; text-align: center">
    <table class="TmplContentPlaceHolder" style=" width: 90%; min-width: 200px; height: 100%; margin: auto;" cellpadding="0" cellspacing="0">
        <thead>
            <tr>
                <td style="text-align: center;">
					<div class="login" style="margin-top: 100px">
                    <div class="logo" title="Slick"><span></span></div></div>
                    <h2 class="ProjectSubTitle">
						<br>
                        Vetturino - Smart Transport
						<br>
						Makers Lab, Tech Mahindra
                    </h2>
                    <p class="ProjectWarning">
                 Tech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise. We are a USD 4.9 billion company with 121,000+ professionals across 90 countries, helping 938 global customers including Fortune 500 companies. Our convergent, digital, design experiences, innovation platforms and reusable assets connect across a number of technologies to deliver tangible business value and experiences to our stakeholders. Tech Mahindra is the highest ranked Non-U.S. company in the Forbes Global Digital 100 list (2018) and in the Forbes Fab 50 companies in Asia (2018).
                    </p>
                </td>
            </tr>
        </thead>
    </table>
</div>

<script>
    function ClsViewAbout()
    {
        this.Init = function (Params)
        {
            //alert(GlbTest);
        }
    }

    //Instantiate An Object for the class
    var CurrentView = new ClsViewAbout();
</script>
