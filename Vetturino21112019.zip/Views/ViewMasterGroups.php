<div class="topcoat-navigation-bar-page">
    <h1 class="topcoat-navigation-bar__title Title">Title</h1>
    <input type="search" class="topcoat-search-input--large TextBoxSearch" value="" placeholder="Search Text">
    <div class="topcoat-button--large--cta Icomatic ButtonPagination" title="Select Page">
        <div class="topcoat-button--cta Webdings ButtonFirst" style="margin-top: 2px;" title="First Page">9</div>
        <div class="topcoat-button--cta Webdings ButtonPrev" style="margin-top: 2px;" title="Previous Page">3</div>
        <span class="TextBoxPage">-</span>
        <div class="topcoat-button--cta Webdings ButtonNext" style="margin-top: 2px;" title="Next Page">4</div>
        <div class="topcoat-button--cta Webdings ButtonLast" style="margin-top: 2px;" title="Last Page">:</div>
    </div>
    <div class="topcoat-button--large--cta Icomatic ButtonAdd" style="margin-top: 3px;" title="Add New Record"></div>
    <div class="topcoat-button--large Webdings ButtonBack" style="margin-top: 3px;" title="Go Back">7</div>
    <div class="topcoat-button--large--cta Wingdings ButtonSave" style="margin-top: 3px; float: right; display: none" title="Save Record"><</div>
    <div class="topcoat-button--large--cta Icomatic ButtonExport" style="margin-top: 3px;" title="Export Data"></div>
    <a class="LinkExport" style="display: none">Export</a>
</div>
<div class="UtListContainer TmplContentPlaceHolder" style="border: none; width: 100%;"></div>
<div class="TmplContentPlaceHolder1" style="border: none; width: 100%; min-height: 300px; height: 100%;"></div>

<link href="Base/Styles/ui.easytree.css" rel="stylesheet" class="skins" type="text/css">
<link href="Base/Styles/jquery-ui.css" rel="stylesheet" type="text/css">
<script src="Base/Scripts/jqueryui.js"></script>
<script src="Base/Scripts/jquery.easytree.min.js"></script>

<script id="TmplList" type="text/x-handlebars-template">
    <table class="" cellpadding="0" cellspacing="0" style="width: 100%;">
        <thead style="background-color: #414144;">
            <tr class="SortHeader">
                <td class="ClickToSort" style="width: 100px;" data-sortfield="OldId">OldId</td>
                <td class="ClickToSort" style="width: 100px;" data-sortfield="ParentId">ParentId</td>
                <td class="ClickToSort" style="width: 100px;" data-sortfield="Name">Name</td>
                <td class="ClickToSort" style="width: 100px;" data-sortfield="IsBaseGroup">IsBaseGroup</td>
                <td style="width: 100px; text-align: right;">Delete</td>
            </tr>
        </thead>
        <tbody>
            {{#.}}
				{{#ifCond IsActive "1"}}
					<tr data-id="{{Id}}" class="ClickToEdit Deleted">
                        {{else}}
					<tr data-id="{{Id}}" class="ClickToEdit">
                        {{/ifCond}}
						<td>{{OldId}}</td>
                        <td>{{ParentId}}</td>
                        <td>{{Name}}</td>
                        <td>
                            <label class="topcoat-checkbox">
                                {{#ifCond IsBaseGroup "1"}}
									<input type="checkbox" disabled data-id="{{Id}}" data-name="{{IsBaseGroup}}" class="CheckBoxIsBaseGroup " checked="checked">
                                {{else}}
									<input type="checkbox" disabled data-id="{{Id}}" data-name="{{IsBaseGroup}}" class="CheckBoxIsBaseGroup">
                                {{/ifCond}}
								<div class="topcoat-checkbox__checkmark"></div>
                            </label>
                        </td>
                        <td>
                            <div class="topcoat-button--large Icomatic ButtonDelete" style="vertical-align: middle; padding: 0 .563rem; float: right" data-id="{{Id}}" disabled></div>
                        </td>
                    </tr>
            {{/.}}
        </tbody>
    </table>
</script>

<script id="TmplAddEdit" type="text/x-handlebars-template">
    <table class="" cellpadding="0" cellspacing="0" style="width: 100%;">
        <thead style="background-color: #414144;">
            <tr>
                <td style="width: 140px;">Entity</td>
                <td>Value</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>OldId</td>
                <td>
                    <input type="text" style="width: 300px" class="topcoat-text-input--large TextBoxOldId" value="{{OldId}}" /></td>
            </tr>
            <tr>
                <td>ParentId</td>
                <td>
                    <input type="text" style="width: 300px" class="topcoat-text-input--large TextBoxParentId" value="{{ParentId}}" /></td>
            </tr>
            <tr>
                <td>Name</td>
                <td>
                    <input type="text" style="width: 300px" class="topcoat-text-input--large TextBoxName" value="{{Name}}" /></td>
            </tr>
            <tr>
                <td>IsBaseGroup</td>
                <td>
                    <label class="topcoat-checkbox">
                        {{#ifCond IsBaseGroup "1"}}
						<input type="checkbox" data-id="{{Id}}" data-name="{{IsBaseGroup}}" class="CheckBoxIsBaseGroup" checked="checked">
                        {{else}}
						<input type="checkbox" data-id="{{Id}}" data-name="{{IsBaseGroup}}" class="CheckBoxIsBaseGroup">
                        {{/ifCond}}
					<div class="topcoat-checkbox__checkmark"></div>
                    </label>
                </td>
            </tr>
            <tr>
                <td>Is Deleted</td>
                <td>
                    <label class="topcoat-checkbox">
                        {{#ifCond IsActive "1"}}
							<input type="checkbox" class="CheckBoxIsDeleted" data-id="{{Id}}" data-name="{{IsActive}}" checked="checked">
                        {{else}}
							<input type="checkbox" class="CheckBoxIsDeleted" data-id="{{Id}}" data-name="{{IsActive}}">
                        {{/ifCond}}
						<div class="topcoat-checkbox__checkmark"></div>
                    </label>
                </td>
            </tr>
        </tbody>
    </table>
</script>

<script>
    function ClsViewMasterap_groups()
    {
        //debugger;

        var This = this;

        this.GetRecordCount = true;
        this.ViewMode = "List";
        this.TmplList = {};
        this.TmplAddEdit = {};
        this.SortField = "OldId";
        this.SortDirection = "ASC";
        this.IdSelected = "";
        this.Paginator = new ClsPaginator();
        this.TitleListMode = "List of ap_groups";
        this.TitleAddMode = "Add New ap_groups";
        this.TitleEditMode = "Edit ap_groups";
        this.QueryCount = "DAap_groupsSelectAllCount";
        this.QueryList = "DAap_groupsSelectAll";
        this.QuerySelect = "DAap_groupsSelect";
        this.QueryDelete = "DAap_groupsDelete";
        this.QueryInsert = "DAap_groupsInsert";
        this.QueryUpdate = "DAap_groupsUpdate";
        this.ExportHeader = '<tr><td class="Header" colspan="5" style="text-align: left">TimeAndCriterion</td></tr><tr><td class="Header">Id</td><td class="Header">OldId</td><td class="Header">ParentId</td><td class="Header">Name</td><td class="Header">IsBaseGroup</td></tr>';
        this.DefaultBlankRecord = { Data: [{ OldId: "", ParentId: "", Name: "", IsBaseGroup: "" }] };

        this.RunQueryInsert = function ()
        {
            return GlbServer.ExecuteQuery
			(
				This.QueryInsert,
				$(".TextBoxOldId").val(),
				$(".TextBoxParentId").val(),
				$(".TextBoxName").val(),
				$(".CheckBoxIsBaseGroup").prop("checked") ? 1 : 0,
				$(".CheckBoxIsDeleted").prop("checked") ? 1 : 0
			);
        };
        this.RunQueryUpdate = function ()
        {
            return GlbServer.ExecuteQuery
				(
					This.QueryUpdate,
				$(".TextBoxOldId").val(),
				$(".TextBoxParentId").val(),
				$(".TextBoxName").val(),
				$(".CheckBoxIsBaseGroup").prop("checked") ? 1 : 0,
				$(".CheckBoxIsDeleted").prop("checked") ? 1 : 0,
				This.IdSelected
				);
        };
        this.RunQueryCount = function ()
        {
            return GlbServer.ExecuteQuery(This.QueryCount, $(".TextBoxSearch").val());
        };
        this.RunQueryList = function ()
        {
            return GlbServer.ExecuteQuery(This.QueryList, $(".TextBoxSearch").val(), This.SortField, This.SortDirection, This.Paginator.PageOffset, This.Paginator.PageSize);
        };
        this.RunQuerySelect = function ()
        {
            return GlbServer.ExecuteQuery(This.QuerySelect, This.IdSelected);
        };
        this.RunQueryDelete = function ()
        {
            return GlbServer.ExecuteQuery(this.QueryDelete, This.IdSelected);
        };

        this.Init = function (Params)
        {
            //Hide Menu and Load the templates
            This.TmplList = Handlebars.compile($("#TmplList").html());
            This.TmplAddEdit = Handlebars.compile($("#TmplAddEdit").html());

            //Setup and Initialise the paginator
            This.Paginator.Init(".ButtonPagination", ".PanelPagination", ".ButtonFirst", ".ButtonLast", ".ButtonPrev", ".ButtonNext", ".TextBoxPage",
                function ()
                {
                    This.Populate("List");
                });
            This.Paginator.SetPageSize(250);

            // Attach & handle events.
            $(".ButtonBack").click(function ()
            {
                This.Populate("List");
                return Common.PrvntEvtPropg();
            });

            $(".TextBoxSearch").on("keyup", function ()
            {
                This.GetRecordCount = true;
                This.Populate("List");
                return Common.PrvntEvtPropg();
            });
            $(".ButtonAdd").click(function ()
            {
                if (Cache.Get("AllowEdit") == "1")
                {
                    This.Populate("Add");
                }
                return Common.PrvntEvtPropg();
            });
            $(".ButtonSave").click(function ()
            {
                if (Cache.Get("AllowEdit") == "1")
                {
                    if (This.ViewMode == "Add")
                    {
                        RetVal = This.RunQueryInsert();
                    }
                    else
                    {
                        RetVal = This.RunQueryUpdate();
                    }
                    if (!RetVal.HasError)
                    {
                        UI.Alert("Info", "Record saved successfully!");
                    }
                    This.Populate("List");
                }
                return Common.PrvntEvtPropg();
            });
            $(".ButtonExport").click(function ()
            {
                var Header = This.ExportHeader.replace('TimeAndCriterion', 'ap_groups Report Generated On: ' + new Date().ToString("dd/mm/yyyy hh:nn:ss") + ' [Search Text: "' + $(".TextBoxSearch").val() + '"]');
                var RetVal = GlbServer.ExportToExcel("DAap_groupsSelectAll", $(".TextBoxSearch").val(), This.SortField, This.SortDirection, 0, 9999999, Header);
                var $ExportLink = $(".LinkExport");

                $ExportLink.attr("href", "./Downloads/" + RetVal.Data);
                $ExportLink[0].click();
            });


            This.Populate("List");
        };

        //------Class Populate Function
        this.Populate = function (GivenMode)
        {
            var RetVal;

            This.ViewMode = (GivenMode ? GivenMode : This.ViewMode);
            if (This.ViewMode != "List")
            {
                $(".TextBoxSearch").hide();
                $(".ButtonPagination").hide();
                $(".ButtonExport").hide();
                $(".ButtonAdd").hide();
                $(".ButtonBack").show();
                $(".ButtonSave").show();
                $(".PopupCombo").click(function ()
                {
                    This.ProcessCombo(this);
                    return Common.PrvntEvtPropg();
                });
                if (This.ViewMode == "Add")
                {
                    $(".TmplContentPlaceHolder").html(This.TmplAddEdit(This.DefaultBlankRecord));
                    UI.SetPageTitle(This.TitleAddMode)
                }
                else if (This.ViewMode == "Edit")
                {
                    RetVal = This.RunQuerySelect();
                    $(".TmplContentPlaceHolder").html(This.TmplAddEdit(RetVal.Data[0]));
                    UI.SetPageTitle(This.TitleEditMode)
                }
            }
            else // This.ViewMode == "List"
            {
                RetVal = This.RunQueryList();
                var TreeData =
                [
                    {
                        "text": "Home"
                    },
                    {
                        "children": [
                        {
                            "text": "Go to Google.com",
                        "tooltip": "Something"
                        },
                        {
                            "text": "Go to Yahoo.com"
                        }
                        ],
                        "isFolder": true,
                        "text": "Folder 1",
                        "tooltip": "Bookmarks"
                    },
                    {
                        "children": [
                        {
                            "text": "Sub Node 1"
                        },
                        {
                            "text": "Sub Node 2"
                        },
                        {
                            "text": "Sub Node 3"
                        }
                        ],
                        "isActive": false,
                        "text": "Node 1"
                    },
                    {
                        "text": "Node 2"
                    }
                ];

                //$(".TmplContentPlaceHolder").html(This.TmplList(RetVal.Data));
                var easyTree = $(".TmplContentPlaceHolder1").easytree({
                    data: TreeData,
                    enableDnd: true,
                    canDrop: function (event, nodes, isSourceNode, source, isTargetNode, target)
                    {
                        // returning true from this event will allow the drop to take place.
                        // In this case if the node has text 'DroppableNode' it will allow a drop to take place regardless of if it is a folder or not.
                        if (isTargetNode && target.text == 'DroppableNode')
                        {
                            return true;
                        }
                        // if not 'DroppableNode' the default behaviour will ensue
                    }
                });

                $(".TextBoxSearch").show();
                $(".ButtonExport").show();
                $(".ButtonAdd").show();
                $(".ButtonSave").hide();
                $(".ButtonBack").hide();
                UI.SetPageTitle(This.TitleListMode)
                $(".SortHeader").find("span").remove();
                $(".SortHeader").find("[data-sortfield='" + This.SortField + "']").append('<span class="Webdings">' + (This.SortDirection == "ASC" ? '5' : '6') + '</span>');
                if (This.Paginator.TotalRecords > 250)
                {
                    $(".ButtonPagination").show();
                }
                else
                {
                    $(".ButtonPagination").hide();
                }
                $(".ButtonDelete").click(function ()
                {
                    if (Cache.Get("AllowEdit") == "1")
                    {
                        This.IdSelected = $(this).data("id");
                        UI.Confirm("Are you sure you want to delete?", function (ButtonClicked)
                        {
                            if (ButtonClicked == "Yes")
                            {
                                RetVal = This.RunQueryDelete()
                                This.Populate("List");
                            }
                        });
                    }
                    return Common.PrvntEvtPropg();
                });

                $(".ClickToEdit").click(function ()
                {
                    if (Cache.Get("AllowEdit") == "1")
                    {
                        This.IdSelected = $(this).data("id");
                        This.Populate("Edit");
                    }
                    return Common.PrvntEvtPropg();
                });

                $(".ClickToSort").click(function ()
                {
                    var FieldClicked = $(this).data("sortfield");

                    if (This.SortField == FieldClicked)
                    {
                        This.SortDirection = (This.SortDirection == "ASC" ? "DESC" : "ASC");
                    }
                    else
                    {
                        $(this).data("sortfield");
                        This.SortField = FieldClicked;
                    }
                    This.Populate("List");
                    return Common.PrvntEvtPropg();
                });
            }
        }
        ///////////////////////////////////////////////////////////////
    }

    //Instantiate An Object for the class
    var CurrentView = new ClsViewMasterap_groups();
</script>
