<div class="topcoat-navigation-bar-page">
	<h1 class="topcoat-navigation-bar__title Title">Title</h1>
	<input type="search" class="topcoat-search-input--large TextBoxSearch" value="" placeholder="Search Text">
	<div class="topcoat-button--large--cta Icomatic ButtonPagination" title="Select Page">
		<div class="topcoat-button--cta Webdings ButtonFirst" style="margin-top: 2px;" title="First Page">9</div>
		<div class="topcoat-button--cta Webdings ButtonPrev" style="margin-top: 2px;" title="Previous Page">3</div>
		<span class="TextBoxPage">-</span>
		<div class="topcoat-button--cta Webdings ButtonNext" style="margin-top: 2px;" title="Next Page">4</div>
		<div class="topcoat-button--cta Webdings ButtonLast" style="margin-top: 2px;" title="Last Page">:</div>
	</div>
	<div class="topcoat-button--large--cta Icomatic ButtonAdd" style="margin-top: 3px;" title="Add New Record"></div>
	<div class="topcoat-button--large Webdings ButtonBack" style="margin-top: 3px;" title="Go Back">7</div>
	<div class="topcoat-button--large--cta Wingdings ButtonSave" style="margin-top: 3px; float: right; display: none" title="Save Record"><</div>
	<div class="topcoat-button--large--cta Icomatic ButtonExport" style="margin-top: 3px;" title="Export Data"></div>
	<a class="LinkExport" style="display:none">Export</a>
</div>
<div class="UtListContainer TmplContentPlaceHolder" style="border: none; width: 100%;"></div>

<!--// The List template -->
<script id="TmplList" type="text/x-handlebars-template">
	<table class="ListTable" cellpadding="0" cellspacing="0" style="">
		<thead style="background-color: #414144;">
			<tr class="SortHeader">
				<td class="ClickToSort" style="width:100px;" data-sortfield="HeadId">Head</td>
				<td class="ClickToSort" style="width:100px;" data-sortfield="Name">Name</td>
				<td style="width:100px; text-align:right;">Delete</td>
			</tr>
		</thead>
		<tbody>
			{{#.}}
			{{#ifCond IsActive "1"}}
			<tr data-id="{{Id}}" class="ClickToEdit Deleted">
				{{else}}
			<tr data-id="{{Id}}" class="ClickToEdit">
				{{/ifCond}}
				<td>{{HeadName}}</td>
				<td>{{Name}}</td>
				<td><div class="topcoat-button--large Icomatic ButtonDelete" style="vertical-align: middle; padding: 0 .563rem; float: right" data-id="{{Id}}" disabled></div></td>
			</tr>
			{{/.}}
		</tbody>
	</table>
</script>

<!--// The Add/Edit template -->
<script id="TmplAddEdit" type="text/x-handlebars-template">
	<table class="" cellpadding="0" cellspacing="0" style="width: 100%;">
		<thead style="background-color: #414144;"><tr><td style="width:140px;">Entity</td><td>Value</td></tr></thead>
		<tbody>
			<tr>
				<td>HeadId</td>
				<td>
					<select class="SelectHead" style="width: 225px;">
						<option value="{{HeadId}}" selected="selected">{{HeadName}}
						<option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type="text" style="width:300px" class="topcoat-text-input--large TextBoxName" value="{{Name}}" /></td>
			</tr>
			<tr>
				<td>Is Deleted</td>
				<td>
					<label class="topcoat-checkbox">
						{{#ifCond IsActive "1"}}
						<input type="checkbox" class="CheckBoxIsDeleted" data-id="{{Id}}" data-name="{{IsActive}}" checked="checked">
						{{else}}
						<input type="checkbox" class="CheckBoxIsDeleted" data-id="{{Id}}" data-name="{{IsActive}}">
						{{/ifCond}}
						<div class="topcoat-checkbox__checkmark"></div>
					</label>
				</td>
			</tr>
		</tbody>
	</table>
</script>

<!--// The The Class Script -->
<script>
	function ClsViewMasterSubHeads()
	{
		//------Variable Declarations
		var This = this;

		this.RetVal;
		this.GetRecordCount = true;
		this.ViewMode = "List";
		this.TmplList = {};
		this.TmplAddEdit = {};
		this.IdSelected = "";
		this.Paginator = new ClsPaginator();
		this.SortDirection = "ASC";
		this.SortField = "HeadId";
		this.TitleListMode = "List of SubHeads";
		this.TitleAddMode = "Add New SubHeads";
		this.TitleEditMode = "Edit SubHeads";
		this.QueryCount = "DASubHeadsSelectAllCount";
		this.QueryList = "DASubHeadsSelectAll";
		this.QuerySelect = "DASubHeadsSelect";
		this.QueryDelete = "DASubHeadsDelete";
		this.QueryInsert = "DASubHeadsInsert";
		this.QueryUpdate = "DASubHeadsUpdate";
		this.ReportName = "Sub Heads";
		this.ExportHeader = '<tr><td class="Header" colspan="3" style="text-align: left">TimeAndCriterion</td></tr><tr><td class="Header">Id</td><td class="Header">HeadId</td><td class="Header">Name</td></tr>';
		this.DefaultBlankRecord = { Data: [{ HeadId: "", Name: "" }] };
		this.ComboArrays = {};
		this.ComboHeadsArray = [];

		//Fetch Data for Combos & later Bind All of them
		this.FetchComboArrays = function ()
		{
			This.ComboArrays.Heads = GlbServer.ExecuteQuery("DAGetHeadsArray").Data;
		};

		this.BindAllCombos = function ()
		{
			UI.BindCombos(".SelectHead", This.ComboArrays.Heads, " -- Select Head -- ");
		};

		//------Calling of Queries
		this.RunQueryInsert = function ()
		{
			return GlbServer.ExecuteQuery
			(
				This.QueryInsert,
				$(".SelectHead").val(),
				$(".TextBoxName").val(),
				$(".CheckBoxIsDeleted").prop("checked") ? 1 : 0
			);
		};
		this.RunQueryUpdate = function ()
		{
			return GlbServer.ExecuteQuery
			(
				This.QueryUpdate,
				$(".SelectHead").val(),
				$(".TextBoxName").val(),
				$(".CheckBoxIsDeleted").prop("checked") ? 1 : 0,
				This.IdSelected
			);
		};
		this.RunQueryCount = function ()
		{
			return GlbServer.ExecuteQuery(This.QueryCount, $(".TextBoxSearch").val());
		};
		this.RunQueryList = function ()
		{
			return GlbServer.ExecuteQuery(This.QueryList, $(".TextBoxSearch").val(), This.SortField, This.SortDirection, This.Paginator.PageOffset, This.Paginator.PageSize);
		};
		this.RunQuerySelect = function ()
		{
			return GlbServer.ExecuteQuery(This.QuerySelect, This.IdSelected);
		};
		this.RunQueryDelete = function ()
		{
			return GlbServer.ExecuteQuery(this.QueryDelete, This.IdSelected);
		};

		this.Init = function (Params)
		{
			//Hide Menu and Load the templates
			UI.SetPageTitle(This.ListMode)
			This.TmplList = Handlebars.compile($("#TmplList").html());
			This.TmplAddEdit = Handlebars.compile($("#TmplAddEdit").html());
			This.FetchComboArrays();

			//Setup and Initialise the paginator
			This.Paginator.Init(".ButtonPagination", ".PanelPagination", ".ButtonFirst", ".ButtonLast", ".ButtonPrev", ".ButtonNext", ".TextBoxPage",
				function ()
				{
					This.Populate("List");
				});
			This.Paginator.SetPageSize(250);

			// Attach & handle events.
			$(".TextBoxSearch").on("keyup", function ()
			{
				// Reset the timer so that any previous keypress are not called back on then callback only if timeout has elapsed
				window.clearTimeout(This.ActiveTimer);
				This.ActiveTimer = window.setTimeout(function ()
				{
					This.GetRecordCount = true;
					This.Populate("List");
				}, 1000);
			});

			$(".ButtonBack").click(function ()
			{
				This.Populate("List");
			});

			$(".ButtonAdd").click(function ()
			{
				if (Cache.Get("AllowEdit") == "1")
				{
					This.Populate("Add");
				}
			});

			$(".ButtonSave").click(function ()
			{
				if (Cache.Get("AllowEdit") == "1")
				{
					This.RetVal = (This.ViewMode == "Add" ? This.RunQueryInsert() : This.RunQueryUpdate());
					if (!This.RetVal.HasError)
					{
						UI.Alert("Info", "Record saved successfully!");
					}
					This.Populate("List");
				}
			});

			$(".ButtonExport").click(function ()
			{
				var $ExportLink = $(".LinkExport");
				var Header = This.ExportHeader.replace("TimeAndCriterion", This.ReportName + " Report Generated On: " + new Date().ToString("dd/mm/yyyy hh:nn:ss") + " [Search Text: '" + $(".TextBoxSearch").val() + "']");
				var RetVal = GlbServer.ExportToExcel(This.QueryList, $(".TextBoxSearch").val(), This.SortField, This.SortDirection, 0, 9999999, Header);

				$ExportLink.attr("href", "./Downloads/" + RetVal.Data);
				$ExportLink[0].click();
			});

			This.Populate("List");
		};

		this.Populate = function (GivenMode)
		{
			//Save the mode
			This.ViewMode = GivenMode;
			if (This.ViewMode == "List")
			{
				//Set UI Elements
				$(".TextBoxSearch").show();
				$(".ButtonExport").show();
				$(".ButtonAdd").show();
				$(".ButtonSave").hide();
				$(".ButtonBack").hide();
				UI.SetPageTitle(This.TitleListMode)

				if (This.GetRecordCount)
				{
					This.RetVal = This.RunQueryCount();
					This.Paginator.SetTotalRecords(This.RetVal.Data[0].TotalRecords);
					This.GetRecordCount = false;
				}
				This.RetVal = This.RunQueryList();

				//Show pagination bar if required and set the data in template and make the table header fixed and then
				$(".ButtonPagination").toggle((This.Paginator.TotalRecords > 250));
				$(".TmplContentPlaceHolder").html(This.TmplList(This.RetVal.Data));
				UI.SetSortHeader(This.SortField, This.SortDirection);
				UI.SetHeaderPos($(".ListTable"), 85);

				//Handle Events
				$(".ButtonDelete").click(function ()
				{
					if (Cache.Get("AllowEdit") == "1")
					{
						This.IdSelected = $(this).data("id");
						UI.Confirm("Are you sure you want to delete?", function (ButtonClicked)
						{
							if (ButtonClicked == "Yes")
							{
								This.RetVal = This.RunQueryDelete()
								This.Populate("List");
							}
						});
					}
				});

				$(".ClickToEdit").click(function ()
				{
					if (Cache.Get("AllowEdit") == "1")
					{
						This.IdSelected = $(this).data("id");
						This.Populate("Edit");
					}
				});

				$(".ClickToSort").click(function ()
				{
					var FieldClicked = $(this).data("sortfield");

					if (This.SortField == FieldClicked)
					{
						This.SortDirection = (This.SortDirection == "ASC" ? "DESC" : "ASC");
					}
					else
					{
						$(this).data("sortfield");
						This.SortField = FieldClicked;
					}
					This.Populate("List");
				});
			}
			else
			{
				//Set UI Elements
				$(".TextBoxSearch").hide();
				$(".ButtonPagination").hide();
				$(".ButtonExport").hide();
				$(".ButtonAdd").hide();
				$(".ButtonBack").show();
				$(".ButtonSave").show();
				UI.SetPageTitle(This.ViewMode == "Add" ? This.TitleAddMode : This.TitleEditMode);

				//Set the data in template and make the table header fixed and then show pagination bar if required
				$(".TmplContentPlaceHolder").html(This.TmplAddEdit(This.ViewMode == "Add" ? This.DefaultBlankRecord : This.RunQuerySelect().Data[0]));

				//Bind Combos
				This.BindAllCombos();
			}
		}
	}

	var CurrentView = new ClsViewMasterSubHeads();
</script>
