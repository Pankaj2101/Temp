<?php
//Author:-Prachi Dabi
//WS To accept Json

// Data="{
// 	"Packets":[
// 		{
// 			"GroupId":"DG00001",
// 			"Timestamp":"",
// 			"Values":[
// 				{
// 					"Id":"DE00001",
// 					"Val":"30",
//                  "Description":""
// 				}
// 			],
//          
// 		}
// 	]
// }"

include (dirname(__FILE__) . "/../Base/ServerScripts/UniteCommon.php");

//$UrlPrefix = "http://vetturino.uniteweb.org";
$UrlPrefix = "http://localhost/Slick";
$GroupId = "";
$Query = "";
$Ip = "";


if(IsPresent("Data"))
{
    $JsonString = $_REQUEST['Data'];
}
else
{
    throw new Exception("Invalid number of Parameters");
}


$Data = json_decode($JsonString, true);
$Data["Ip"] = GetIp();
$GroupId = $Data["Packets"][0]["GroupId"];
WriteToLog("JSON Data", $JsonString);

$Query = urlencode(json_encode($Data));

$Response = file_get_contents(
    $UrlPrefix."/Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAInsertDeviceJson&Params[]=".$Query);

$Response = json_decode($Response, true);

if(!$Response["HasError"])
{
    $Response1 = file_get_contents(
        $UrlPrefix."/Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAGetDeviceTag&Parse=FALSE&Params[]=".$GroupId);
}
print_r($Response1);
?>
