<?php
    //Array of Global Queries - Note this is an associative array of named queries 
    $UserQueries = array
    (
		"DAGetLastTenRecordsRPM" =>
		"SELECT 
			* 
		FROM 
			(SELECT 
				DATE_FORMAT(EventDate,'%H:%i:%s') AS EventDate, Value 
			FROM 
				`ap_devicelog` 
			WHERE 
				Tag = 'DE00025' 
			ORDER BY 
				`ap_devicelog`.`EventDate`  DESC 
			LIMIT 
				10)x 
		ORDER BY 
			EventDate ASC",

		"DAGetDeviceLog"=>
			"SELECT
				DATE_FORMAT(EventDate, '%d/%m %H:%i:%s') AS At,
				L.Tag,
				L.Value AS `Values`
			FROM 
				ap_devicelog AS L, ap_devicetag AS T
			WHERE 
				L.Tag = T.Tag
				AND DATE(L.EventDate) = '%%Param1%%'
				AND L.Tag = '%%Param2%%'
				AND EventDate < GetIst()
				AND NOT L.InActive
			ORDER BY 
				L.EventDate",
			//LIMIT 20",			
			
		"DAGetDeviceLogEnergy"=>
		"SELECT
			DATE_FORMAT(EventDate, '%d/%m %H:%i:%s') AS At,
			L.Tag,
			L.Value AS `Values`	
		FROM
			ap_devicelogenergy AS L, ap_devicetag AS T
		WHERE
			L.Tag = T.Tag
			AND DATE(L.EventDate) = '%%Param1%%'
			AND L.Tag = '%%Param2%%'
			AND EventDate < GetIst()
			AND NOT L.InActive	
		ORDER BY 
			L.EventDate",			
	
		"DAInsertDeviceData" => 
			"INSERT INTO 
				ap_devicelog
				(EventDate, Tag, Value, Description, ModifiedOn, ModifiedBy, IsSynched, InActive)
			VALUES 
				(GetIst(), '%%Param2%%', '%%Param3%%', 'Periodic Read', GetIst(), '%%Param1%%', '1', '0');",
	
		"DAGetDeviceTags" =>
			"SELECT DISTINCT
				Tag, Name
			FROM
				ap_devicetag
			WHERE
				InActive = 0",
		
		//Queries to Manage Table: fw_companies
		"DAfw_companiesSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_companies
			WHERE
				CompanyId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR WebSite LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%'",

		"DAfw_companiesSelectAll" => 
			"SELECT
				Id, CompanyId, Name, Address, City, PinCode, WebSite, Email, Phones, PanNo, GstNo, InActive
			FROM
				fw_companies
			WHERE
				CompanyId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR WebSite LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_companiesSelect" => 
			"SELECT
				Id, CompanyId, Name, Address, City, PinCode, WebSite, Email, Phones, PanNo, GstNo, InActive
			FROM
				fw_companies
			WHERE
				Id = '%%Param1%%'",

		"DAfw_companiesDelete" => 
			"UPDATE
				fw_companies
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_companiesInsert" => 
			"INSERT INTO fw_companies
				(CompanyId, Name, Address, City, PinCode, WebSite, Email, Phones, PanNo, GstNo, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', '%%Param11%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_companiesUpdate" => 
			"UPDATE 
				fw_companies
			SET 
				CompanyId = '%%Param1%%', Name = '%%Param2%%', Address = '%%Param3%%', City = '%%Param4%%', PinCode = '%%Param5%%', WebSite = '%%Param6%%', Email = '%%Param7%%', Phones = '%%Param8%%', PanNo = '%%Param9%%', GstNo = '%%Param10%%', InActive = '%%Param11%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param12%%'",
			
		//Queries to Manage Table: fw_config
		"DAfw_configSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_config
			WHERE
				ConfigId LIKE '%%%Param1%%%' OR Value LIKE '%%%Param1%%%' OR IsBase LIKE '%%%Param1%%%'",

		"DAfw_configSelectAll" => 
			"SELECT
				Id, ConfigId, Value, IsBase, InActive
			FROM
				fw_config
			WHERE
				ConfigId LIKE '%%%Param1%%%' OR Value LIKE '%%%Param1%%%' OR IsBase LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_configSelect" => 
			"SELECT
				Id, ConfigId, Value, IsBase, InActive
			FROM
				fw_config
			WHERE
				Id = '%%Param1%%'",

		"DAfw_configDelete" => 
			"UPDATE
				fw_config
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_configInsert" => 
			"INSERT INTO fw_config
				(ConfigId, Value, IsBase, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_configUpdate" => 
			"UPDATE 
				fw_config
			SET 
				ConfigId = '%%Param1%%', Value = '%%Param2%%', IsBase = '%%Param3%%', InActive = '%%Param4%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param5%%'",
			
		//Queries to Manage Table: ap_devices
		"DAap_devicesSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				ap_devices
			WHERE
				DeviceId LIKE '%%%Param1%%%' OR TagId LIKE '%%%Param1%%%'",

		"DAap_devicesSelectAll" => 
			"SELECT
				Id, DeviceId, TagId, InActive
			FROM
				ap_devices
			WHERE
				DeviceId LIKE '%%%Param1%%%' OR TagId LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAap_devicesSelect" => 
			"SELECT
				Id, DeviceId, TagId, InActive
			FROM
				ap_devices
			WHERE
				Id = '%%Param1%%'",

		"DAap_devicesDelete" => 
			"UPDATE
				ap_devices
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAap_devicesInsert" => 
			"INSERT INTO ap_devices
				(DeviceId, TagId, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAap_devicesUpdate" => 
			"UPDATE 
				ap_devices
			SET 
				DeviceId = '%%Param1%%', TagId = '%%Param2%%', InActive = '%%Param3%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param4%%'",

		//Queries to Manage Table: ap_devicetag
		"DAap_devicetagSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				ap_devicetag
			WHERE
				Tag LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Location LIKE '%%%Param1%%%' OR TagType LIKE '%%%Param1%%%' OR Units LIKE '%%%Param1%%%' OR Latitude LIKE '%%%Param1%%%' OR Longitude LIKE '%%%Param1%%%' OR Icon LIKE '%%%Param1%%%' OR Validate LIKE '%%%Param1%%%' OR MinVal LIKE '%%%Param1%%%' OR MaxVal LIKE '%%%Param1%%%' OR NomLowValue LIKE '%%%Param1%%%' OR NomHighValue LIKE '%%%Param1%%%' OR ScaleOffset LIKE '%%%Param1%%%' OR ScaleFactor LIKE '%%%Param1%%%' OR AllowNegative LIKE '%%%Param1%%%' OR OwnerId LIKE '%%%Param1%%%' OR AlertEmailsTo LIKE '%%%Param1%%%' OR Description LIKE '%%%Param1%%%' OR  DATE_FORMAT(ModifiedOn, '%d/%m/%Y') LIKE '%%%Param1%%%' OR ModifiedBy LIKE '%%%Param1%%%' OR IsSynched LIKE '%%%Param1%%%' OR InActive LIKE '%%%Param1%%%'",

		"DAap_devicetagSelectAll" => 
			"SELECT
				Id, Tag, Name, Location, TagType, Units, Latitude, Longitude, Icon, Validate, MinVal, MaxVal, NomLowValue, NomHighValue, ScaleOffset, ScaleFactor, AllowNegative, OwnerId, AlertEmailsTo, Description,  DATE_FORMAT(ModifiedOn, '%d/%m/%Y') AS FModifiedOn, ModifiedBy, IsSynched, InActive, InActive
			FROM
				ap_devicetag
			WHERE
				Tag LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Location LIKE '%%%Param1%%%' OR TagType LIKE '%%%Param1%%%' OR Units LIKE '%%%Param1%%%' OR Latitude LIKE '%%%Param1%%%' OR Longitude LIKE '%%%Param1%%%' OR Icon LIKE '%%%Param1%%%' OR Validate LIKE '%%%Param1%%%' OR MinVal LIKE '%%%Param1%%%' OR MaxVal LIKE '%%%Param1%%%' OR NomLowValue LIKE '%%%Param1%%%' OR NomHighValue LIKE '%%%Param1%%%' OR ScaleOffset LIKE '%%%Param1%%%' OR ScaleFactor LIKE '%%%Param1%%%' OR AllowNegative LIKE '%%%Param1%%%' OR OwnerId LIKE '%%%Param1%%%' OR AlertEmailsTo LIKE '%%%Param1%%%' OR Description LIKE '%%%Param1%%%' OR  DATE_FORMAT(ModifiedOn, '%d/%m/%Y') LIKE '%%%Param1%%%' OR ModifiedBy LIKE '%%%Param1%%%' OR IsSynched LIKE '%%%Param1%%%' OR InActive LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAap_devicetagSelect" => 
			"SELECT
				Id, Tag, Name, Location, TagType, Units, Latitude, Longitude, Icon, Validate, MinVal, MaxVal, NomLowValue, NomHighValue, ScaleOffset, ScaleFactor, AllowNegative, OwnerId, AlertEmailsTo, Description,  DATE_FORMAT(ModifiedOn, '%d/%m/%Y') AS FModifiedOn, ModifiedBy, IsSynched, InActive, InActive
			FROM
				ap_devicetag
			WHERE
				Id = '%%Param1%%'",

		"DAap_devicetagDelete" => 
			"UPDATE
				ap_devicetag
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAap_devicetagInsert" => 
			"INSERT INTO ap_devicetag
				(Tag, Name, Location, TagType, Units, Latitude, Longitude, Icon, Validate, MinVal, MaxVal, NomLowValue, NomHighValue, ScaleOffset, ScaleFactor, AllowNegative, OwnerId, AlertEmailsTo, Description, ModifiedOn, ModifiedBy, IsSynched, InActive, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', '%%Param11%%', '%%Param12%%', '%%Param13%%', '%%Param14%%', '%%Param15%%', '%%Param16%%', '%%Param17%%', '%%Param18%%', '%%Param19%%', '%%Param20%%', '%%Param21%%', '%%Param22%%', '%%Param23%%', '%%Param24%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAap_devicetagUpdate" => 
			"UPDATE 
				ap_devicetag
			SET 
				Tag = '%%Param1%%', Name = '%%Param2%%', Location = '%%Param3%%', TagType = '%%Param4%%', Units = '%%Param5%%', Latitude = '%%Param6%%', Longitude = '%%Param7%%', Icon = '%%Param8%%', Validate = '%%Param9%%', MinVal = '%%Param10%%', MaxVal = '%%Param11%%', NomLowValue = '%%Param12%%', NomHighValue = '%%Param13%%', ScaleOffset = '%%Param14%%', ScaleFactor = '%%Param15%%', AllowNegative = '%%Param16%%', OwnerId = '%%Param17%%', AlertEmailsTo = '%%Param18%%', Description = '%%Param19%%', ModifiedOn = '%%Param20%%', ModifiedBy = '%%Param21%%', IsSynched = '%%Param22%%', InActive = '%%Param23%%', InActive = '%%Param24%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param25%%'",

		//Queries to Manage Table: ap_drivers
		"DAap_driversSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				ap_drivers
			WHERE
				Driverid LIKE '%%%Param1%%%' OR UnitId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Gender LIKE '%%%Param1%%%' OR Age LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR IdProof LIKE '%%%Param1%%%' OR PhoneNumber LIKE '%%%Param1%%%'",

		"DAap_driversSelectAll" => 
			"SELECT
				Id, Driverid, UnitId, Name, Gender, Age, Address, IdProof, PhoneNumber, InActive
			FROM
				ap_drivers
			WHERE
				Driverid LIKE '%%%Param1%%%' OR UnitId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Gender LIKE '%%%Param1%%%' OR Age LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR IdProof LIKE '%%%Param1%%%' OR PhoneNumber LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAap_driversSelect" => 
			"SELECT
				Id, Driverid, UnitId, Name, Gender, Age, Address, IdProof, PhoneNumber, InActive
			FROM
				ap_drivers
			WHERE
				Id = '%%Param1%%'",

		"DAap_driversDelete" => 
			"UPDATE
				ap_drivers
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAap_driversInsert" => 
			"INSERT INTO ap_drivers
				(Driverid, UnitId, Name, Gender, Age, Address, IdProof, PhoneNumber, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAap_driversUpdate" => 
			"UPDATE 
				ap_drivers
			SET 
				Driverid = '%%Param1%%', UnitId = '%%Param2%%', Name = '%%Param3%%', Gender = '%%Param4%%', Age = '%%Param5%%', Address = '%%Param6%%', IdProof = '%%Param7%%', PhoneNumber = '%%Param8%%', InActive = '%%Param9%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param10%%'",
			
			
		//Queries to Manage Table: fw_menurights
		"DAfw_menurightsSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_menurights
			WHERE
				MenuId LIKE '%%%Param1%%%' OR UserId LIKE '%%%Param1%%%' OR UnitId LIKE '%%%Param1%%%' OR RightToAdd LIKE '%%%Param1%%%' OR RightToEdit LIKE '%%%Param1%%%' OR RightToDelete LIKE '%%%Param1%%%'",

		"DAfw_menurightsSelectAll" => 
			"SELECT
				Id, MenuId, UserId, UnitId, RightToAdd, RightToEdit, RightToDelete, InActive
			FROM
				fw_menurights
			WHERE
				MenuId LIKE '%%%Param1%%%' OR UserId LIKE '%%%Param1%%%' OR UnitId LIKE '%%%Param1%%%' OR RightToAdd LIKE '%%%Param1%%%' OR RightToEdit LIKE '%%%Param1%%%' OR RightToDelete LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_menurightsSelect" => 
			"SELECT
				Id, MenuId, UserId, UnitId, RightToAdd, RightToEdit, RightToDelete, InActive
			FROM
				fw_menurights
			WHERE
				Id = '%%Param1%%'",

		"DAfw_menurightsDelete" => 
			"UPDATE
				fw_menurights
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_menurightsInsert" => 
			"INSERT INTO fw_menurights
				(MenuId, UserId, UnitId, RightToAdd, RightToEdit, RightToDelete, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_menurightsUpdate" => 
			"UPDATE 
				fw_menurights
			SET 
				MenuId = '%%Param1%%', UserId = '%%Param2%%', UnitId = '%%Param3%%', RightToAdd = '%%Param4%%', RightToEdit = '%%Param5%%', RightToDelete = '%%Param6%%', InActive = '%%Param7%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param8%%'",

		"DAfw_menusSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_menus
			WHERE
				MenuId LIKE '%%%Param1%%%' OR MenuOrder LIKE '%%%Param1%%%' OR Icon LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR GroupOrder LIKE '%%%Param1%%%' OR Group LIKE '%%%Param1%%%' OR GroupIcon LIKE '%%%Param1%%%' OR Description LIKE '%%%Param1%%%' OR FormName LIKE '%%%Param1%%%' OR Link LIKE '%%%Param1%%%'",

		"DAfw_menusSelectAll" => 
			"SELECT
				Id, MenuId, MenuOrder, Icon, Name, GroupOrder, Group, GroupIcon, Description, FormName, Link, InActive
			FROM
				fw_menus
			WHERE
				MenuId LIKE '%%%Param1%%%' OR MenuOrder LIKE '%%%Param1%%%' OR Icon LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR GroupOrder LIKE '%%%Param1%%%' OR Group LIKE '%%%Param1%%%' OR GroupIcon LIKE '%%%Param1%%%' OR Description LIKE '%%%Param1%%%' OR FormName LIKE '%%%Param1%%%' OR Link LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_menusSelect" => 
			"SELECT
				Id, MenuId, MenuOrder, Icon, Name, GroupOrder, Group, GroupIcon, Description, FormName, Link, InActive
			FROM
				fw_menus
			WHERE
				Id = '%%Param1%%'",

		"DAfw_menusDelete" => 
			"UPDATE
				fw_menus
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_menusInsert" => 
			"INSERT INTO fw_menus
				(MenuId, MenuOrder, Icon, Name, GroupOrder, Group, GroupIcon, Description, FormName, Link, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', '%%Param11%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_menusUpdate" => 
			"UPDATE 
				fw_menus
			SET 
				MenuId = '%%Param1%%', MenuOrder = '%%Param2%%', Icon = '%%Param3%%', Name = '%%Param4%%', GroupOrder = '%%Param5%%', Group = '%%Param6%%', GroupIcon = '%%Param7%%', Description = '%%Param8%%', FormName = '%%Param9%%', Link = '%%Param10%%', InActive = '%%Param11%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param12%%'",
			
		//Queries to Manage Table: fw_unitrights
		"DAfw_unitrightsSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_unitrights
			WHERE
				UserId LIKE '%%%Param1%%%' OR UnitId LIKE '%%%Param1%%%' OR LastUsed LIKE '%%%Param1%%%'",

		"DAfw_unitrightsSelectAll" => 
			"SELECT
				Id, UserId, UnitId, LastUsed, InActive
			FROM
				fw_unitrights
			WHERE
				UserId LIKE '%%%Param1%%%' OR UnitId LIKE '%%%Param1%%%' OR LastUsed LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_unitrightsSelect" => 
			"SELECT
				Id, UserId, UnitId, LastUsed, InActive
			FROM
				fw_unitrights
			WHERE
				Id = '%%Param1%%'",

		"DAfw_unitrightsDelete" => 
			"UPDATE
				fw_unitrights
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_unitrightsInsert" => 
			"INSERT INTO fw_unitrights
				(UserId, UnitId, LastUsed, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_unitrightsUpdate" => 
			"UPDATE 
				fw_unitrights
			SET 
				UserId = '%%Param1%%', UnitId = '%%Param2%%', LastUsed = '%%Param3%%', InActive = '%%Param4%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param5%%'",

		//Queries to Manage Table: fw_units
		"DAfw_unitsSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_units
			WHERE
				UnitId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR CompanyId LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%' OR TermsConditions LIKE '%%%Param1%%%'",

		"DAfw_unitsSelectAll" => 
			"SELECT
				Id, UnitId, Name, CompanyId, Address, City, PinCode, Email, Phones, PanNo, GstNo, TermsConditions, InActive
			FROM
				fw_units
			WHERE
				UnitId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR CompanyId LIKE '%%%Param1%%%' OR Address LIKE '%%%Param1%%%' OR City LIKE '%%%Param1%%%' OR PinCode LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Phones LIKE '%%%Param1%%%' OR PanNo LIKE '%%%Param1%%%' OR GstNo LIKE '%%%Param1%%%' OR TermsConditions LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_unitsSelect" => 
			"SELECT
				Id, UnitId, Name, CompanyId, Address, City, PinCode, Email, Phones, PanNo, GstNo, TermsConditions, InActive
			FROM
				fw_units
			WHERE
				Id = '%%Param1%%'",

		"DAfw_unitsDelete" => 
			"UPDATE
				fw_units
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_unitsInsert" => 
			"INSERT INTO fw_units
				(UnitId, Name, CompanyId, Address, City, PinCode, Email, Phones, PanNo, GstNo, TermsConditions, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', '%%Param11%%', '%%Param12%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_unitsUpdate" => 
			"UPDATE 
				fw_units
			SET 
				UnitId = '%%Param1%%', Name = '%%Param2%%', CompanyId = '%%Param3%%', Address = '%%Param4%%', City = '%%Param5%%', PinCode = '%%Param6%%', Email = '%%Param7%%', Phones = '%%Param8%%', PanNo = '%%Param9%%', GstNo = '%%Param10%%', TermsConditions = '%%Param11%%', InActive = '%%Param12%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param13%%'",

		"DAfw_usersSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				fw_users
			WHERE
				UserId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Password LIKE '%%%Param1%%%' OR EmployeeId LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Mobile LIKE '%%%Param1%%%' OR  DATE_FORMAT(LastAccessed, '%d/%m/%Y') LIKE '%%%Param1%%%'",

		"DAfw_usersSelectAll" => 
			"SELECT
				Id, UserId, Name, Password, EmployeeId, Email, Mobile,  DATE_FORMAT(LastAccessed, '%d/%m/%Y') AS FLastAccessed, InActive
			FROM
				fw_users
			WHERE
				UserId LIKE '%%%Param1%%%' OR Name LIKE '%%%Param1%%%' OR Password LIKE '%%%Param1%%%' OR EmployeeId LIKE '%%%Param1%%%' OR Email LIKE '%%%Param1%%%' OR Mobile LIKE '%%%Param1%%%' OR  DATE_FORMAT(LastAccessed, '%d/%m/%Y') LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAfw_usersSelect" => 
			"SELECT
				Id, UserId, Name, Password, EmployeeId, Email, Mobile,  DATE_FORMAT(LastAccessed, '%d/%m/%Y') AS FLastAccessed, InActive
			FROM
				fw_users
			WHERE
				Id = '%%Param1%%'",

		"DAfw_usersDelete" => 
			"UPDATE
				fw_users
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAfw_usersInsert" => 
			"INSERT INTO fw_users
				(UserId, Name, Password, EmployeeId, Email, Mobile, LastAccessed, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAfw_usersUpdate" => 
			"UPDATE 
				fw_users
			SET 
				UserId = '%%Param1%%', Name = '%%Param2%%', Password = '%%Param3%%', EmployeeId = '%%Param4%%', Email = '%%Param5%%', Mobile = '%%Param6%%', LastAccessed = '%%Param7%%', InActive = '%%Param8%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param9%%'",

		//Queries to Manage Table: ap_vehicles
		"DAap_vehiclesSelectAllCount" => 
			"SELECT
				COUNT(*) AS TotalRecords
			FROM
				ap_vehicles
			WHERE
				VechicleNumber LIKE '%%%Param1%%%' OR GroupId LIKE '%%%Param1%%%' OR Driverid LIKE '%%%Param1%%%' OR Model LIKE '%%%Param1%%%' OR Type LIKE '%%%Param1%%%' OR InMaintenance LIKE '%%%Param1%%%' OR Issued LIKE '%%%Param1%%%' OR DistanceTravelled LIKE '%%%Param1%%%' OR IssuedDistanceTravelled LIKE '%%%Param1%%%'",

		"DAap_vehiclesSelectAll" => 
			"SELECT
				Id, VechicleNumber, GroupId, Driverid, Model, Type, InMaintenance, Issued, DistanceTravelled, IssuedDistanceTravelled, InActive
			FROM
				ap_vehicles
			WHERE
				VechicleNumber LIKE '%%%Param1%%%' OR GroupId LIKE '%%%Param1%%%' OR Driverid LIKE '%%%Param1%%%' OR Model LIKE '%%%Param1%%%' OR Type LIKE '%%%Param1%%%' OR InMaintenance LIKE '%%%Param1%%%' OR Issued LIKE '%%%Param1%%%' OR DistanceTravelled LIKE '%%%Param1%%%' OR IssuedDistanceTravelled LIKE '%%%Param1%%%'
			ORDER BY
				%%Param2%% %%Param3%%
			LIMIT %%Param4%%, %%Param5%%",

		"DAap_vehiclesSelect" => 
			"SELECT
				Id, VechicleNumber, GroupId, Driverid, Model, Type, InMaintenance, Issued, DistanceTravelled, IssuedDistanceTravelled, InActive
			FROM
				ap_vehicles
			WHERE
				Id = '%%Param1%%'",

		"DAap_vehiclesDelete" => 
			"UPDATE
				ap_vehicles
			SET
				InActive = 1,  Modified = '%%Param0%%, ' + GetIst()
			WHERE
				Id = '%%Param1%%'",

		"DAap_vehiclesInsert" => 
			"INSERT INTO ap_vehicles
				(VechicleNumber, GroupId, Driverid, Model, Type, InMaintenance, Issued, DistanceTravelled, IssuedDistanceTravelled, InActive, Modified)
			VALUES 
				('%%Param1%%', '%%Param2%%', '%%Param3%%', '%%Param4%%', '%%Param5%%', '%%Param6%%', '%%Param7%%', '%%Param8%%', '%%Param9%%', '%%Param10%%', CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s')))",

		"DAap_vehiclesUpdate" => 
			"UPDATE 
				ap_vehicles
			SET 
				VechicleNumber = '%%Param1%%', GroupId = '%%Param2%%', Driverid = '%%Param3%%', Model = '%%Param4%%', Type = '%%Param5%%', InMaintenance = '%%Param6%%', Issued = '%%Param7%%', DistanceTravelled = '%%Param8%%', IssuedDistanceTravelled = '%%Param9%%', InActive = '%%Param10%%', Modified = CONCAT('%%Param0%%, ', DATE_FORMAT(GetIst(), '%Y/%m/%d %H:%i:%s'))
			WHERE 
				Id = '%%Param11%%'",

		//Queries to Manage Table: ap_devicelog and ap_devicetag
		"DASelectDeviceComparativeDataUL" =>
			"SELECT
				DATE_FORMAT(EventDate, '%d/%m %H:%i') AS At,
				L.Tag,
				L.Value AS `Values`
			FROM 
				ap_devicelog AS L, ap_devicetag AS T
			WHERE 
				L.Tag = T.Tag
				AND DATE(L.EventDate) = '%%Param1%%'
				AND L.Tag = '%%Param2%%'
				AND EventDate < GetIst()
				AND NOT L.InActive
				AND L.Description = 'Periodic Read'
			ORDER BY 
				L.EventDate",

		"DASelectDeviceComparativeDataCount" =>
			"SELECT
				COUNT(*) AS TotalRecords
			FROM 
				ap_devicelog AS L, ap_devicetag AS T
			WHERE 
				L.Tag = T.Tag
				AND DATE(L.EventDate) = '%%Param1%%'
				AND L.Tag = '%%Param2%%'
				AND EventDate < GetIst()
				AND NOT L.InActive
				AND L.Description = 'Periodic Read'
			ORDER BY 
				L.EventDate",

		//Queries for Reports -> Alerts
		"DASelectDeviceAlertDataUL" =>
			"SELECT
				DATE_FORMAT(EventDate, '%d/%m %H:%i') AS At,
				L.Tag,
				L.Value AS `Values`
			FROM 
				ap_devicelog AS L, ap_devicetag AS T
			WHERE 
				L.Tag = T.Tag
				AND DATE(L.EventDate) = '%%Param1%%'
				AND L.Tag = '%%Param2%%'
				AND EventDate < GetIst()
				AND NOT L.InActive
				AND L.Description = 'Alert'
			ORDER BY 
				L.EventDate",

		"DASelectDeviceAlertDataCount" =>
			"SELECT
				COUNT(*) AS TotalRecords
			FROM 
				ap_devicelog AS L, ap_devicetag AS T
			WHERE 
				L.Tag = T.Tag
				AND DATE(L.EventDate) = '%%Param1%%'
				AND L.Tag = '%%Param2%%'
				AND EventDate < GetIst()
				AND NOT L.InActive
				AND L.Description = 'Alert'
			ORDER BY 
				L.EventDate",
							
		"DAInsertDeviceJson" =>
            		"CALL `JsonInsert`('%%Param1%%');",

		"DAGetDeviceTag" =>
            		"SELECT 
		                `Tag`,`Name`,`Units`,`Auxiliary`,`Validate` 
            		FROM 
                		`ap_devicetag`
	            	INNER JOIN ap_device on ap_devicetag.Tag = ap_device.TagId 
        		WHERE 
                		ap_device.DeviceId = '%%Param1%%';",

		"DAInsertDeviceJson" =>
            		"CALL `JsonInsert1`('%%Param1%%');"

				
	);
?>