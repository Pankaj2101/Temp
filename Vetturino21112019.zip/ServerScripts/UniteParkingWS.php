<?php

//$UrlPrefix = "http://vtest.pankajs.me";
$UrlPrefix = "http://localhost/Slick";

$Ip = "";

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);

if (!empty($_SERVER['HTTP_CLIENT_IP'])) 
    {
        $Ip = $_SERVER['HTTP_CLIENT_IP'];
    } 
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
    {
        $Ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } 
    else 
    {
        $Ip = $_SERVER['REMOTE_ADDR'];
    }

    $Response = file_get_contents($UrlPrefix . "./Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAParkingWSInsert&Params[]=" . "Web Service");
    
    echo "Data saved <br>";
    echo $Response;
    
    function curl_get_contents($url)
    {
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      $data = curl_exec($ch);
      curl_close($ch);
      return $data;
    }

?>
