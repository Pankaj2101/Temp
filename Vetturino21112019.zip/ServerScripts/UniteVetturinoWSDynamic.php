<?php
//Author:-Prachi Dabi
//WS To accept Json

// Data="{
// 	"Packets":[
// 		{
// 			"GroupId":"DG00001",
// 			"Timestamp":"",
// 			"Values":[
// 				{
// 					"Id":"DE00001",
// 					"Val":"30",
//                  "Description":""
// 				}
// 			],
//          
// 		}
// 	]
// }"

include (dirname(__FILE__) . "/../Base/ServerScripts/UniteCommon.php");

$UrlPrefix = "http://vetturino.uniteweb.org";
//$UrlPrefix = "http://localhost/Slick";

$Query = "";
$Ip = "";
$Timestamp = "";
$GroupId = "";
$Id = "";
$Val = "";

if(IsPresent("Data"))
{
    $JsonString = $_REQUEST['Data'];
}
else
{
    throw new Exception("Invalid number of Parameters");
}

$Data = json_decode($JsonString, true);
$Packet = $Data["Packets"];
//print_r($Packet);
$Ip = GetIp();

WriteToLog("JSON Data", $JsonString);

foreach($Packet as $Dataset)
{
    $GroupId = $Dataset["GroupId"];
    $Timestamp = $Dataset["Timestamp"];
//    print_r($Timestamp.PHP_EOL);
//    print_r($Dataset["Values"]);
    $Values = $Dataset["Values"];
    foreach($Values as $value)
    {
        $Id = $value["Id"];
        $Val = $value["Val"];
        $Description = $value["Description"];
        $Query = $Query."('".$GroupId."','".$Timestamp."','".$Id."','".$Val."','".$Description."','NULL',GetIst(),'".$Ip."','1','0'),";
    }
    
}
print_r($Query);
$Query = urlencode(rtrim($Query,","));
$Response = file_get_contents(
    $UrlPrefix."/Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAInsertDeviceJson&Params[]=".$Query);
print_r($Response);
// $Response = json_decode($Response, true);
// if(!$Response["HasError"])
// {
//     $Response = file_get_contents(
//         $UrlPrefix."/Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAGetDeviceTag&Parse=FALSE&Params[]=".$GroupId);
//     #print_r($Response);
// }
// print_r($Response);
?>
