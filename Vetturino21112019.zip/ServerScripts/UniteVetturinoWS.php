<?php

$UrlPrefix = "http://vetturino.uniteweb.org";
//$UrlPrefix = "http://localhost/slick";

$Ip = "";
$Id = "";
$VAL = "";

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);

if (!empty($_SERVER['HTTP_CLIENT_IP'])) 
    {
        $Ip = $_SERVER['HTTP_CLIENT_IP'];
    } 
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
    {
        $Ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } 
    else 
    {
        $Ip = $_SERVER['REMOTE_ADDR'];
    }

    if(isset($_REQUEST["id"]))       $Id     = urlencode($_REQUEST['id']);
    if(isset($_REQUEST["val"]))      $VAL    = urlencode($_REQUEST['val']);

    file_put_contents("../Logs/log_" . date('Ymd') . ".txt", date("H:i:s." . substr((string)microtime(), 1, 8)) . " - [" . $Ip . "] - [" .
        "Id = " . $Id . 
        ", VAL = " . $VAL .
        "] - [" . "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]" . "]" . PHP_EOL, FILE_APPEND);

    if(
        isset($Id)         &&
        isset($VAL)
    )
    {
        $Response = file_get_contents(
            $UrlPrefix . "./Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAInsertDeviceData&" .
            "Params[]=" . $Ip . "&" .
            "Params[]=" . $Id . "&" . 
            "Params[]=" . $VAL);
    
        echo "Data saved <br>";
        //echo $Response;
    }
    else
    {
        $response = file_get_contents($UrlPrefix . "/PhpScripts/AjaxServerAccess.php?WebMethod=ExecuteQuery");
        echo "Data not saved";
    }
    
    function curl_get_contents($url)
    {
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      $data = curl_exec($ch);
      curl_close($ch);
      return $data;
    }

?>
