<?php
	//Global Variables
	if (IsLocal())
	{
		$DBName = "uniteslick";
		$DBUrl = "localhost";		
		$DBUser = "root";			
		$DBPassword = "pass";
	}
	else
	{		
		$DBName = "uniteslick";
		$DBUrl = "localhost";		
		$DBUser = "root";			
		$DBPassword = "pass";
	}

	$GWUserId = "info@unite.org";
	$GWPassword = "password";
	$DefaultMailSenderName = "Administrator";
	$DefaultMailSmtpServer = "unite.org";
	$DefaultMailSmtpPort = 25;
	$DefaultMailSmtpUser = "info@uniteorg.com";
	$DefaultMailSmtpPassword = "password";
?>