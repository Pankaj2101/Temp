<?php
//Author:-Prachi Dabi
//WS accept camera input

include (dirname(__FILE__) . "/../Base/ServerScripts/UniteCommon.php");
$UrlPrefix = "http://localhost/Slick";

$Query = "";
$Ip = "";
$Timestamp = "";
$GroupId = "";
$Id = "";
$Val = "";



if(IsPresent("Data"))
{
    $JsonString = $_REQUEST['Data'];
}
else
{
    throw new Exception("Invalid number of Parameters");
}

$Data = json_decode($JsonString, true);
$Dataset = $Data["Packets"];
print_r($Data);
$Ip = GetIp();

WriteToLog("JSON Data", $JsonString);

$GroupId = $Dataset["GroupId"];
$Timestamp = $Dataset["Timestamp"];
$Values = $Dataset["Values"];
foreach($Values as $value)
{
    if(file_exists($_FILES['file']['tmp_name']))
    {
        // print_r($_FILES["file"]["size"]);
        if($_FILES["file"]["size"] > 0)
        {
            $image = $_FILES['file']['tmp_name'];
            $target_path = "../DeviceIMages/".date('dmY_His').".mp4";
            move_uploaded_file($_FILES["file"]["tmp_name"],$target_path);
            $Id = $value["Id"];
            $Val = $value["Val"];
            $Description = $value["Description"];
            $Location = $target_path;
            $Query = $Query."('".$GroupId."','".$Timestamp."','".$Id."','".$Val."','".$Description."','".$Location."',GetIst(),'".$Ip."','1','0'),";        
        }
    }
}

$Query = urlencode(rtrim($Query,","));
$Response = file_get_contents(
    $UrlPrefix."/Base/ServerScripts/UniteAjaxQueryDirect.php?Query=DAInsertDeviceDataNew&Parse=TRUE&Params[]=".$Query);
print_r($Response);
?>